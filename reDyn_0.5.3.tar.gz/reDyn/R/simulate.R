## simulate path ----
#' simulate a path, integrating out behavior state \eqn{z(t)}
#'
#' @param sigsq_mu variance of Brownian motion when \eqn{z(t) = 0} (scalar)
#' @param tausq variance of Brownian motion when \eqn{z(t) = 1} (scalar, default is \code{0}).
#' @param beta effects of covariates, \eqn{X}, on movement when \eqn{z(t) = 1} (vector)
#' @param theta effects of covariates, \eqn{W}, on \eqn{g(t)} (vector)
#' @param alpha factor by which re-charge out-paces depletion (default = 1)
#' @param sigsq_s measurement error variance (scalar)
#' @param mu0 initial location (vector of length 2)
#' @param g0 initial value of \eqn{g(t)} (scalar)
#' @param gmax maximum possible value of \eqn{g(t)} (scalar)
#' @param times (vector)
#' @param obstimes subset of times (vector)
#' @param gradX pre-calculated gradient of each covariate in \code{RasterStack} \eqn{X} (output from \code{ctmcmove::rast.grad()})
#' @param W covariates effecting \eqn{g(t)} (vector)
#'
#' @importFrom stats pnorm rnorm
#'
#' @return object of class \code{recharge_path}
#' @export
sim_path <- function(sigsq_mu, tausq, beta, theta, alpha = 1, sigsq_s = 0,
                     mu0 = c(0.5, 0.5), g0 = 0, gmax = Inf,
                     times, obstimes, gradX, W){
  TIMES <- length(times)
  mu <- gradp_beta <- matrix(NA, TIMES, 2)
  g <- rho <- z <- rep(NA, TIMES)
  mu[1, ] <- mu0
  gradp_beta[1, ] <- get_gradp(mu_tm1 = mu[1, ], gradX = gradX, beta = beta)
  g[1] <- g0
  rho[1] <- pnorm(-g0)
  for(t in 2:TIMES){
    dt <- diff(times[(t-1):t])
    g[t] <- get_g(g_tm1 = g[t-1], mu_tm1 = mu[t-1, ], W = W,
                  theta = theta, alpha = alpha, dt = dt, gmax = gmax)
    rho[t] <- pnorm(-g[t])
    gradp_beta[t, ] <- get_gradp(mu_tm1 = mu[t-1, ], gradX = gradX, beta = beta)
    mu[t, ] <- mu[t-1, ] + (gradp_beta[t, ]*dt + rnorm(2, sd = sqrt(tausq * dt)))*(rho[t]) +
      rnorm(2, sd = sqrt(sigsq_mu*dt))*(1-rho[t])
    while(min(mu[t, ]) < 0 || max(mu[t, ]) > 1){
      message("Warning: reflected path at boundary.")
      mu[t, ] = mu[t, ] + c(-2*mu[t, 1], 0)*(mu[t, 1] < 0) + c(0, -2*mu[t, 2])*(mu[t, 2] < 0) +
        c(2*(1-mu[t, 1]), 0)*(mu[t, 1] > 1) + c(0, 2*(1-mu[t, 2]))*(mu[t, 2] > 1)
    }
  }
  OBSTIMES <- length(obstimes)
  s <- mu[times %in% obstimes, ] + matrix(rnorm(2*OBSTIMES, sd = sqrt(sigsq_s)), ncol = 2)
  out <- list("s" = s, "mu" = mu, "g" = g, "g0" = g0, "gmax" = gmax, "rho" = rho,
              "sigsq_mu" = sigsq_mu, "tausq" = tausq, "beta" = beta,
              "theta" = theta, "alpha" = alpha, "sigsq_s" = sigsq_s,
              "times" = times, "obstimes" = obstimes,
              "W" = W, "gradX" = gradX, "gradp_beta" = gradp_beta)
  class(out) <- "reDyn_path"
  return(out)
}

#' simulate a path using latent behavior states \eqn{z(t)}
#'
#' @param sigsq_mu variance of Brownian motion when \eqn{z(t) = 0} (scalar)
#' @param tausq variance of Brownian motion when \eqn{z(t) = 1} (scalar, default is \code{0}).
#' @param beta effects of covariates, \eqn{X}, on movement when \eqn{z(t) = 1} (vector)
#' @param theta effects of covariates, \eqn{W}, on \eqn{g(t)} (vector)
#' @param alpha factor by which re-charge out-paces depletion (default = 1)
#' @param sigsq_s measurement error variance (scalar)
#' @param gamma friction coefficient (for \code{method = "velocity"})
#' @param mu0 initial location (vector of length 2)
#' @param v0 initial velocity (for \code{method = "velocity"})
#' @param g0 initial value of \eqn{g(t)} (scalar)
#' @param gmax maximum possible value of \eqn{g(t)} (scalar)
#' @param times (vector)
#' @param obstimes subset of times (vector)
#' @param gradX pre-calculated gradient of each covariate in \code{RasterStack} \eqn{X} (output from \code{ctmcmove::rast.grad()})
#' @param W covariates effecting \eqn{g(t)} (vector)
#' @param method either \code{"position"} or \code{"velocity"}
#' @param innovation either \code{"BM"} or \code{"IBM"}
#' @param seed integer
#'
#' @importFrom stats pnorm rnorm
#'
#' @return object of class \code{recharge_path}
#' @export
sim_path_z <- function(sigsq_mu, tausq, beta, theta, alpha = 1, sigsq_s = 0, gamma = 0.1,
                       mu0 = c(0.5, 0.5), v0 = c(0, 0), g0 = 0, gmax = Inf,
                       times, obstimes, gradX, W, method = "position", innovation = "BM", seed = 1){
  set.seed(seed)
  TIMES <- length(times)
  mu <- v <- gradp_beta <- matrix(NA, TIMES, 2)
  g <- rho <- z <- rep(NA, TIMES)
  mu[1, ] <- mu0
  v[1, ] <- v0
  gradp_beta[1, ] <- get_gradp(mu_tm1 = mu[1, ], gradX = gradX, beta = beta)
  g[1] <- g0
  rho[1] <- pnorm(-g0)
  z[1] <- sample(x = 1:0, size = 1, prob = c(rho[1], 1 - rho[1]))
  ext <- extent(W)
  for(t in 2:TIMES){
    dt <- diff(times[(t-1):t])
    dtm1 <- diff(times[(t-2):(t-1)])
    g[t] <- get_g(g_tm1 = g[t-1], mu_tm1 = mu[t-1, ], W = W,
                  theta = theta, alpha = alpha, dt = dt, gmax = gmax)
    rho[t] <- pnorm(-g[t])
    z[t] <- sample(x = 1:0, size = 1, prob = c(rho[t], 1 - rho[t]))
    gradp_beta[t, ] <- get_gradp(mu_tm1 = mu[t-1, ], gradX = gradX, beta = beta)
    if(method == "position"){
      if(innovation == "BM"){
        mu[t, ] <- mu[t-1, ] + (gradp_beta[t, ]*dt + rnorm(2, sd = sqrt(tausq * dt)))*(z[t] == 1) +
          rnorm(2, sd = sqrt(sigsq_mu*dt)*(z[t] == 0))
      } else if(innovation == "IBM"){
        if(t == 2){
          mu[t, ] <- mu[t-1, ] + (gradp_beta[t, ]*dt + rnorm(2, sd = sqrt(tausq * dt)))*(z[t] == 1) +
            rnorm(2, sd = sqrt(sigsq_mu*dt)*(z[t] == 0))
        } else {
          mu[t, ] <- 2 * mu[t-1, ] - mu[t-2, ] - gradp_beta[t-1, ]*dtm1*(z[t-1] == 1) +
            (gradp_beta[t, ]*dt + rnorm(2, sd = sqrt(tausq * dt)))*(z[t] == 1)
            rnorm(2, sd = sqrt(sigsq_mu*dt)*(z[t] == 0))
        }
      }
    } else if(method == "velocity"){
      v[t, ] <- (1 - gamma) * v[t-1, ] +
        (gradp_beta[t, ]*dt + rnorm(2, sd = sqrt(tausq * dt)))*(z[t] == 1) +
        rnorm(2, sd = sqrt(sigsq_mu*dt)*(z[t] == 0))
      mu[t, ] <- mu[t - 1, ] + v[t, ] * dt
    } else {
      stop('"method" must be either "position" or "velocity".')
    }
    while(min(mu[t, 1]) < ext@xmin || max(mu[t, 1]) > ext@xmax ||
          min(mu[t, 2]) < ext@ymin || max(mu[t, 2]) > ext@ymax){
      message("Warning: reflected path at boundary.")
      mu[t, ] = mu[t, ] +
        c(-2*(mu[t, 1] - ext@xmin), 0)*(mu[t, 1] < ext@xmin) +
        c(0, -2*(mu[t, 2] - ext@ymin))*(mu[t, 2] < ext@ymin) +
        c(-2*(mu[t, 1] - ext@xmax), 0)*(mu[t, 1] > ext@xmax) +
        c(0, -2*(mu[t, 2] - ext@ymax))*(mu[t, 2] > ext@ymax)
    }
  }
  OBSTIMES <- length(obstimes)
  s <- mu[times %in% obstimes, ] + matrix(rnorm(2*OBSTIMES, sd = sqrt(sigsq_s)), ncol = 2)
  out <- list("s" = s, "mu" = mu, "z" = z, "sigsq_s" = sigsq_s,
              "beta" = beta, "sigsq_mu" = sigsq_mu, "tausq" = tausq,
              "theta" = theta, "alpha" = alpha, "g0" = g0, "gmax" = gmax,
              "g" = g, "rho" = rho,
              "times" = times, "obstimes" = obstimes,
              "W" = W, "gradX" = gradX, "gradp_beta" = gradp_beta)
  class(out) <- "reDyn_path"
  return(out)
}
