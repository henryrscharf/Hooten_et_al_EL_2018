## MH random walk ----
#' Metropolis sampler with normal proposal distribution and diagonal proposal variance.
#' This sampler accepts both vectors and scalars.
#'
#' @param prev previous value (either scalar or vector)
#' @param proposal proposed value. If \code{NULL}, default, a value will be proposed from a normal distribution with standard deviation given by \code{tune}.
#' @param tune tuning parameter (if \code{prev} is a vector, this can either be a scalar, or a vector of the same length)
#' @param get_ld log density to evaluate for Metropolis ratio. The first argument should be where \code{prev} goes.
#' @param log_prior function of random variable (or vector) proportional to the log of the prior distribution
#' @param ld_prev log density for previous value (if \code{NULL}, will be calculated)
#' @param log_proposal logical. Should proposals be done on the log scale? If \code{TRUE}, \code{tune} is taken to be the tuning parameter of the log-transformed variable.
#' @param verbose_sampler logical. Print information about sampler.
#' @param ... arguments passed to \code{get_ld()}
#'
#' @importFrom stats rnorm runif
#'
#' @return list: \code{draw} is vector of same length as \code{prev}, \code{ld_fc} is the log density full conditional
#' @export
sample_rw <- function(prev, proposal = NULL, tune, get_ld, log_prior = function(x) 0,
                      ld_prev = NULL, log_proposal = FALSE,
                      verbose_sampler = F, ...){
  excess.num <- excess.den <- NULL
  if(is.null(proposal)){
    proposal <- rnorm(length(prev), mean = prev, sd = tune)
    if(log_proposal){
      proposal <- exp(rnorm(length(prev), mean = log(prev), sd = tune))
    }
  }
  num <- get_ld(proposal, ...)
  if(is.list(num)){
    excess.num <- num[-1]; num <- num[[1]]
  }
  den <- ld_prev
  if(is.null(den) || length(den) == 0){
    den <- get_ld(prev, ...)
    if(is.list(den)){
      excess.den <- den[-1]; den <- den[[1]]
    }
  }
  prob <- min(exp(num + log_prior(proposal) - den - log_prior(prev)), 1)
  if(verbose_sampler){
    message(paste(c("proposal =", proposal, "num =", num + log_prior(proposal),
                    "\n prev =", prev, "den =", den + log_prior(prev), "\n prob =", prob,
                    "\n ld function:", as.character(substitute(get_ld)))))
  }
  tryCatch(expr = {accept <- runif(n = 1) < prob},
           error = function(err){message("get_ld = ", get_ld)})
  if(accept){
    return(list("draw" = proposal, "ld" = num, "excess" = excess.num))
  } else {
    return(list("draw" = prev, "ld" = den, "excess" = excess.den))
  }
}

#' Metropolis sampler with normal proposal distribution and general proposal variance.
#' This sampler accepts both vectors and scalars.
#'
#' @param prev previous value (vector)
#' @param proposal proposed values. If \code{NULL}, default, values will be proposed from a normal distribution with covariance given by \code{tune_cov}.
#' @param tune_cov covariance matrix for proposal distribution. Dimensions should equal length of \code{prev}.
#' @param tune_cov_chol logical. Passed to \code{isChol} argument in \code{mvnfast::rmvn()}.
#' @param get_ld function to evaluate for Metropolis ratio. The first argument should be where \code{prev} goes.
#' @param log_prior function of random variable (or vector) proportional to the log of the prior distribution
#' @param ld_prev log density for previous value (if \code{NULL}, will be calculated)
#' @param verbose_sampler logical. Print information about sampler.
#' @param ... arguments passed to \code{get_ld()}
#'
#' @importFrom mvnfast rmvn
#'
#' @return list: \code{draw} is vector of same length as \code{prev}, \code{ld_fc} is the log density full conditional
#' @export
vec_sample_RW <- function(prev, proposal = NULL, tune_cov, tune_cov_chol = FALSE,
                          get_ld, log_prior = NULL, ld_prev = NULL,
                          verbose_sampler = F, ...){
  excess.num <- excess.den <- NULL
  if(is.null(proposal)){
    zero_vars <- which(diag(tune_cov) == 0)
    if(length(zero_vars) > 0){
      tune_cov_sub <- tune_cov[-zero_vars, -zero_vars]
      proposal <- c(prev)
      proposal[-zero_vars] <- proposal[-zero_vars] +
        c(rmvn(n = 1, mu = rep(0, length(prev[-zero_vars])), sigma = tune_cov_sub, isChol = tune_cov_chol))
    } else {
      proposal <- c(rmvn(n = 1, mu = c(prev), sigma = tune_cov, isChol = tune_cov_chol))
    }
  }
  if(!is.null(dim(prev))){
    proposal <- array(proposal, dim = dim(prev))
  }
  num <- get_ld(proposal, ...)
  if(is.list(num)){
    excess.num <- num[-1]; num <- num[[1]]
  }
  den <- ld_prev
  if(is.null(den) || length(den) == 0){
    den <- get_ld(prev, ...)
    if(is.list(den)){
      excess.den <- den[-1]; den <- den[[1]]
    }
  }
  prob <- min(exp(num + log_prior(proposal) - den - log_prior(prev)), 1)
  tryCatch(expr = {accept <- runif(n = 1) < prob},
           error = function(err){message("get_ld = ", get_ld)})
  if(verbose_sampler){
    message("\n proposal = ", paste(c("", rep(", ", length(proposal) - 1)), proposal, sep = ""))
    message("\n prev = ", paste(c("", rep(", ", length(prev) - 1)), prev, sep = ""))
    message(paste("\n num =", num + log_prior(proposal),
                  "\n den =", den + log_prior(prev), "\n prob =", prob, "\b accept =", accept,
                  "\n ld function:", as.character(substitute(get_ld))))
  }
  if(accept){
    return(list("draw" = proposal, "ld" = num, "excess" = excess.num))
  } else {
    return(list("draw" = prev, "ld" = den, "excess" = excess.den))
  }
}
## tuning ----
#' Update tuning parameter
#'
#' @param batch vector of draws associated with current \code{batch_no}
#' @param batch_no index of current batch (integer)
#' @param tuning_param tuning parameter used to generate current batch (scalar)
#' @param target target acceptance rate (scalar between 0 and 1, default is 0.44)
#'
#' @return scalar
#' @export
update_tuning <- function(batch, batch_no, tuning_param = 1, target = 0.44) {
  batch_size <- length(batch)
  accepted <- sum(diff(batch) != 0)
  log_tuning_param <- log(tuning_param)
  adjust <- (batch_no + 1)^(-0.5)
  if(accepted / (batch_size - 1) > target){
    new_tuning_param <- exp(log_tuning_param + adjust)
  } else {
    new_tuning_param <- exp(log_tuning_param - adjust);
  }
  return(new_tuning_param);
}

#' Update tuning parameter (see chapter 8 of Computational Statistics by Givens and Hoeting)
#'
#' @param batch matrix of draws associated with current batch (dimensions: length of parameter vector, batch size)
#' @param batch_no index of current batch (integer)
#' @param tuning_param tuning parameter used to generate current batch (scalar)
#' @param tune_cov tuning covariance matrix used to generate current batch (square matrix with dimension equal to length of parameter vector)
#' @param target target acceptance rate. Default is 0.23.
#' @param verbose_tuning logical. Print information about tuning.
#'
#' @importFrom stats cov
#'
#' @return list of new tuning parameter and tuning covariance
#' @export
vec_update_TUNING <- function(batch, batch_no, tuning_param = 1, tune_cov = diag(rep(1, dim(batch)[1])),
                              target = 0.23, verbose_tuning = F) {
  batch_size <- dim(batch)[2]
  accepted <- t(apply(batch, 1, function(x) x[-1] != x[-length(x)]))
  if(length(which(apply(accepted, 2, function(x) x == x[1]) == FALSE)) != 0){
    if(verbose_tuning) message("Acceptance rate error in update_TUNING(). Parameters do not appear to be accepted as a block.")
  }
  log_tuning_param <- log(tuning_param)
  adjust <- (batch_no + 1)^(-0.5)
  batch_cov <- cov(t(batch))
  if(sum(is.nan(batch_cov)) > 0 & sum(is.infinite(batch[, 1])) > 0){
    batch_cov[is.nan(batch_cov)] <- 0
  }
  new_tune_cov <- tune_cov + adjust * (batch_cov - tune_cov)
  new_tuning_param <- exp(log_tuning_param + adjust*sign(sum(accepted[1, ]) / (batch_size - 1) - target))
  return(list("param" = new_tuning_param, "tune_cov" = new_tune_cov));
}
## inverse gamma ----
#' dinvgamma is basically cribbed from MCMCpack but with log option
#'
#' @param x vector of quantiles
#' @param shape shape parameter. Must be positive.
#' @param scale scale parameter. Must be strictly positive.
#'
#' @return density
#' @export
dinvgamma <- function (x, shape, scale = 1){
  if (shape <= 0 | scale <= 0) {
    stop("Shape or scale parameter negative in dinvgamma().\n")
  }
  log.density <- rep(-Inf, length(x))
  alpha <- shape
  beta <- scale
  log.density[x > 0] <- alpha * log(beta) - lgamma(alpha) - (alpha + 1) * log(x[x > 0]) - (beta / x[x > 0])
  return(log.density)
}

#' dinvgamma is cribbed from MCMCpack
#'
#' @param n number of observations.
#' @param shape shape parameter. Must be positive.
#' @param scale scale parameter. Must be strictly positive.
#'
#' @importFrom stats rgamma
#'
#' @return random variable
#' @export
rinvgamma <- function (n, shape, scale = 1){
  return(1/rgamma(n = n, shape = shape, rate = scale))
}

