#' plot simulated path
#'
#' @param x object of class \code{reDyn_path} (result of call to \code{sim_path()})
#' @param background background image for two-dimensional plot. Defaults to last layer of \code{W} in \code{path}
#' @param obs_colors color of observed locations plot characters
#' @param bg_colors color palette passed to \code{image(background)}
#' @param xtra_plots logical. Should extra diagnostic plots be shown.
#' @param oma passed to \code{par(oma = ...)}
#' @param ... additional arguments passed to \code{image(...)}
#'
#' @importFrom grDevices gray.colors
#' @importFrom graphics abline image layout par plot points segments
#' @importFrom raster image rasterToContour
#' @importFrom stats quantile
#' @importFrom scales alpha muted
#' @importFrom viridis magma
#'
#' @return NULL
#' @export
plot.reDyn_path <- function(x, background = NULL, obs_colors = 1,
                            bg_colors = gray.colors(1e2, 0.3, 0.9),
                            xtra_plots = FALSE, oma = c(2.5, 0, 0, 0), ...){
  if(is.null(background)){
    background <- x$W
  }
  TIMES <- length(x$times)
  layout(matrix(c(1, 1, rep(2:3, rep(2, 2))), ncol = 2, byrow = T),
         heights = c(1, 0.2, 0.2))
  if(xtra_plots){
    layout(matrix(c(1, 1, rep(2:5, rep(2, 4))), ncol = 2, byrow = T),
           heights = c(1, 0.2, 0.2, 0.2, 0.2))
  }
  par(mar = c(4, 4, 3, 1), oma = oma)
  image(background[[1]], col = bg_colors, asp = 1, bty = "n", axes = F, xlab = "", ylab = "", ...)
  W_theta <- calc(x$W, function(w) w %*% x$theta)
  image(W_theta > 0, col = c(NA, alpha("#4d9221", 0.6)), add = T)
  # lines(rasterToContour(background[[1]], levels = 0), lty = 3, lwd = 2)
  segments(x0 = x$mu[-TIMES, 1], y0 = x$mu[-TIMES, 2],
           x1 = x$mu[-1, 1], y1 = x$mu[-1, 2],
           col = magma(TIMES, alpha = 0.6), lwd = 2)
  points(x$s, pch = 16, cex = 0.8, col = obs_colors)
  par(mar = c(1, 4.1, 1, 1))
  plot(x$times, x$g, type = "n", ylim = range(x$g, x$g0), ylab = "g", xlab = "", xaxt = "n")
  abline(h = 0, lty = 2, lwd = 2, col = "darkgray")
  lines(x$times, x$g, lwd = 2)
  abline(h = x$gmax, col = muted("red"), lty = 2, lwd = 2)
  plot(x$times, x$rho, type = "n", ylim = c(-0.05, 1.05),
       ylab = expression(rho), xlab = "", xaxt = "n")
  abline(h = 0.5, lty = 2, lwd = 2, col = "darkgray")
  segments(x0 = x$times[1:(TIMES-1)], x1 = x$times[2:TIMES], y0 = x$rho[-TIMES], y1 = x$rho[-1],
           col = magma(TIMES), lwd = 2)
  if(!is.null(x$z)){
    z_subset <- seq(1, TIMES, l=min(3000, TIMES))
    points(x$times[z_subset], x$z[z_subset]*1.08 - 0.04, pch = 15, cex = 0.8,
           col = alpha(1, max(0.06, 1/TIMES)))
  }
  if(xtra_plots){
    plot(x$times[-1], x$gradp_beta[-1, 1]*diff(x$times),
         ylim = range(0, quantile(c(x$gradp_beta[-1, 1]*diff(x$times), diff(x$mu[, 1])),
                                  probs = c(0.025, 0.975))),
         type = "h", col = alpha("blue", 0.5),
         ylab = expression(paste(nabla[x]*p%.%dt, " and ", d*mu[x](t))), xlab = "", xaxt = "n")
    points(x$times[-1], diff(x$mu[, 1]), type = "h", col = alpha("red", 0.5))
    plot(x$times[-1], x$gradp_beta[-1, 2]*diff(x$times),
         ylim = range(0, quantile(c(x$gradp_beta[-1, 2]*diff(x$times), diff(x$mu[, 2])),
                                  probs = c(0.025, 0.975))),
         type = "h", col = alpha("blue", 0.5),
         ylab = expression(paste(nabla[y]*p%.%dt, " and ", d*mu[y](t))), xlab = "time", xpd = T)
    points(x$times[-1], diff(x$mu[, 2]), type = "h", col = alpha("red", 0.5))
  }
  return(NULL)
}

#' compute acceptance rate for chain of draws
#'
#' @param chain vector of draws
#'
#' @return scalar
get_ar <- function(chain){
  sum(diff(chain) != 0)/(length(chain) - 1)
}

#' make diagnostic plots based on mcmc chains
#'
#' @param x object of class \code{reDyn_mcmc}
#' @param ... additional arguments passed to \code{matplot(...)} (\code{type = "trace"}) or \code{plot(...)} (\code{type = "tuning"})
#' @param used_iterations index of iterations to be used in plots. Default is entire chains
#' @param truth list of true values with names matching those in \code{x$chains}
#' @param type one of \code{"trace"} for trace plots (default), \code{"path"} for posterior summary of \eqn{\mu}, \code{"energetics"}, \code{"effects"}, or \code{"tuning"} for checks on adaptive tuning
#' @param background raster
#' @param W supply raster layers for energetics if not saved in \code{x}
#' @param W_tilde_proj_mat default is identity matrix
#' @param X_names names for \eqn{beta} effects
#' @param W_names names for \eqn{theta} effects
#'
#' @importFrom viridis viridis
#' @importFrom graphics abline layout par plot matplot boxplot lines text rasterImage axis polygon rect rug title mtext
#' @importFrom scales muted alpha
#' @importFrom stats median
#' @importFrom RColorBrewer brewer.pal
#' @importFrom raster calc
#' @importFrom grDevices rgb as.raster colorRamp
#'
#' @return NULL
#' @export
plot.reDyn_mcmc <- function(x, ..., used_iterations = NULL, truth = list(),
                            type = "trace", background = NULL, W = NULL,
                            W_tilde_proj_mat = NULL, X_names = NULL, W_names = NULL){
  plot_used_iterations <- used_iterations
  if(is.null(used_iterations)){
    if(!is.null(x$used_iterations)){
      plot_used_iterations <- x$used_iterations
      if(type == "tuning" & mean(diff(plot_used_iterations)) > 1){
        message("Not all iterations were saved, cannot produce tuning diagnostic plots.")
        return(NULL)
      }
      used_iterations <- 1:dim(x$chains$alpha)[2]
    } else {
      used_iterations <- 1:(x$N_iterations + 1)
      plot_used_iterations <- used_iterations
    }
  }
  TIMES <- length(x$data$times)
  if(type == "energetics"){
    ## check for W in x or use W if available
    if(!is.null(W)){
      x$data$W <- W
    }
    ## calc
    beta_median <- apply(matrix(x$chains$beta[, used_iterations], nrow = nrow(x$chains$beta)), 1, median)
    theta_median <- apply(matrix(x$chains$theta[, used_iterations], nrow = nrow(x$chains$theta)), 1, median)
    W_theta_median <- calc(x$data$W, function(x) x %*% theta_median)
    mu_median <- apply(x$chains$mu[, , used_iterations], 1:2, median)
    g_median <- get_g_all(g0 = median(x$chains$g0[used_iterations]), mu = mu_median, W = x$data$W,
                          theta = matrix(theta_median, nrow = nrow(x$chains$theta)),
                          alpha = median(x$chains$alpha[used_iterations]),
                          times = x$data$times, gmax = median(x$chains$gmax[used_iterations]))
    g_color_range <- range(g_median)
    g_color_range <- g_color_range / max(abs(g_color_range)) / 2 + 0.5
    g_color_fn <- colorRamp(brewer.pal(n = 11, name = "PiYG"))
    g_colors <- rgb(g_color_fn(g_median / max(abs(range(g_median))) / 2 + 0.5), maxColorValue = 255)
    gs <- sapply(X = sample(used_iterations, min(200, length(used_iterations))),
                 FUN = function(iter){
                   g <- get_g_all(g0 = x$chains$g0[iter], mu = x$chains$mu[, , iter], W = x$data$W,
                                  theta = x$chains$theta[, iter], alpha = x$chains$alpha[iter],
                                  times = x$data$times, gmax = x$chains$gmax[iter])
                   return(g)
                 })
    ## layout
    layout(matrix(c(2, 3, 4, 5, 1, 1, 4, 5), 4, 2), heights = c(1, 1, 2/3, 2/3), widths = c(1, 1))
    par(mar = c(1, 1, 2, 3))
    ## background
    if(!is.null(background)){
      image(background, col = gray.colors(1e2), asp = 1, bty = "n", axes = F, main = "")
      title(main = names(background), line = 0, cex.main = 2)
      image(W_theta_median > 0, col = c(NA, alpha("#35978f", 0.4)), add = T)
    } else {
      image(W_theta_median > 0, col = c(NA, alpha("#35978f", 0.4)), asp = 1, axes = F)
    }
    # tryCatch(expr = {
    #   lines(rasterToContour(W_theta_median, levels = 0), lty = 3, lwd = 2)
    # }, error = function(err) message("Could not draw contours around recharge landscape."))
    ## path
    lines(truth$mu, col = "darkred", lwd = 2)
    segments(x0 = mu_median[-nrow(mu_median), 1], y0 = mu_median[-nrow(mu_median), 2],
             x1 = mu_median[-1, 1], y1 = mu_median[-1, 2], col = g_colors, lwd = 2)
    ## legend
    legend_color_inds <- seq(g_color_range[2], g_color_range[1], l = 7)
    legend_raster <- as.raster(matrix(rgb(g_color_fn(legend_color_inds), maxColorValue = 255), ncol = 1))
    ext_X <- extent(W_theta_median)
    rasterImage(legend_raster, xleft = ext_X@xmax + 0.01 * (ext_X@xmax - ext_X@xmin),
                xright = ext_X@xmax + 0.03 * (ext_X@xmax - ext_X@xmin),
                ybottom = ext_X@ymin + 0.25 * (ext_X@ymax - ext_X@ymin),
                ytop = ext_X@ymax - 0.25 * (ext_X@ymax - ext_X@ymin), interpolate = F, xpd = T)
    text(x = ext_X@xmax + 0.03 * (ext_X@xmax - ext_X@xmin),
         y = ext_X@ymax - 0.20 * (ext_X@ymax - ext_X@ymin), labels = "g(t)", font = 2, xpd = T)
    text(x = ext_X@xmax + 0.06 * (ext_X@xmax - ext_X@xmin),
         y = ext_X@ymax - 0.25 * (ext_X@ymax - ext_X@ymin), labels = signif(max(g_median), 3),
         cex = 0.8, xpd = T)
    text(x = ext_X@xmax + 0.06 * (ext_X@xmax - ext_X@xmin),
         y = ext_X@ymin + 0.25 * (ext_X@ymax - ext_X@ymin), labels = signif(min(g_median), 3),
         cex = 0.8, xpd = T)
    text(x = ext_X@xmax + 0.04 * (ext_X@xmax - ext_X@xmin),
         y = ext_X@ymin + 0.25 * (ext_X@ymax - ext_X@ymin) +
           (0.5 - g_color_range[1]) / diff(g_color_range) * 0.5 * (ext_X@ymax - ext_X@ymin),
         labels = 0, cex = 0.8, xpd = T)
    labels <- c("x", "y")
    par(mar = c(2, 4, 1, 3))
    for(d in 1:2){
      plot(x$data$times, x$chains$mu[, d, 1], type = "n", xlab = "", ylab = labels[d],
           main = "", bty = "n", xaxt = "n")
      if(inherits(background, "RasterLayer")){
        marginal_bg <- extract(background, mu_median)
        unit_marginal_bg <- (marginal_bg - min(marginal_bg)) / diff(range(marginal_bg))
        scaled_marginal_bg <- unit_marginal_bg * diff(par()$usr[3:4]) + par()$usr[3]
        grad_bg <- diff(marginal_bg) / sqrt(diff(mu_median[, 1])^2 + diff(mu_median[, 2])^2)
        unit_grad_bg <- grad_bg / max(abs(grad_bg)) / 2 + 0.5
        grad_bg_raster <-
          t(matrix(rgb(colorRamp(c(brewer.pal(n = 7, name = "RdBu")[7], "darkgray",
                                   brewer.pal(n = 7, name = "RdBu")[1]))(unit_grad_bg),
                       maxColorValue = 255),
                   nrow = TIMES - 1, ncol = 3e2))
        rasterImage(grad_bg_raster, xleft = x$data$times[1], ybottom = par()$usr[3],
                    xright = x$data$times[TIMES], ytop = par()$usr[4], interpolate = F)
        polygon(x = c(x$data$times, rev(x$data$times)),
                y = c(scaled_marginal_bg, rep(par()$usr[4], TIMES)),
                border = NA, col = "gray")
        lines(x$data$times, scaled_marginal_bg, lwd = 2, col = alpha(1, 0.4))
      } else {
        rect(par()$usr[1], par()$usr[2], par()$usr[3], par()$usr[4], col = "gray")
      }
      if(d == 1){
        rug(x$data$times[extract(W_theta_median, mu_median) > 0], lwd = 2, line = 1.75,
            col = "#35978f")
      }
      if(d == 2){
        axis(1)
      }
      lines(truth$times, truth$mu[, d], col = "darkred", lwd = 1.5)
      mu_subset <- sort(sample(used_iterations, min(length(used_iterations), 1e2)))
      for(mu_i in mu_subset){
        segments(x0 = x$data$times[-TIMES], y0 = x$chains$mu[-TIMES, d, mu_i],
                 x1 = x$data$times[-1], y1 = x$chains$mu[-1, d, mu_i], col = alpha(g_colors, 0.5),
                 lwd = 2)
      }
      points(x$data$obstimes, x$data$s[, d], pch = 19, cex = 0.5)
    }
    ##
    matplot(x$data$times, gs, type = "l", xlab = "time", lty = 1, lwd = 2,
            col = scales::alpha(1, 0.1), ylim = range(gs, truth$g), bty = "n", ylab = "g")
    segments(x0 = x$data$times[-TIMES], y0 = g_median[-TIMES],
             x1 = x$data$times[-1], y1 = g_median[-1], col = g_colors, lwd = 2)
    # abline(h = median(x$chains$gmax[used_iterations]), lty = 2, lwd = 2, col = "darkred")
    abline(h = 0, lty = 2, lwd = 2, col = "gray")
    lines(truth$times, truth$g, lwd = 2, col = "darkred")
    abline(h = truth$gmax, lwd = 2, lty = 2, col = "darkred")
    matplot(x$data$times, pnorm(-gs), type = "l", xlab = "time", lty = 1, lwd = 2,
            col = scales::alpha(1, 0.1), ylim = c(0, 1), bty = "n", ylab = expression(rho))
    segments(x0 = x$data$times[-TIMES], y0 = pnorm(-g_median[-TIMES]),
             x1 = x$data$times[-1], y1 = pnorm(-g_median[-1]), col = g_colors, lwd = 2)
    if(!is.null(truth$g)){
      lines(truth$times, pnorm(-truth$g), lwd = 2, col = "darkred")
    }
    points(x$data$times, rowMeans(x$chains$z), pch = 16, cex = 0.6)
    return(NULL)
  }
  nplots <- length(x$chains) - length(x$fixed) - !("mu" %in% x$fixed)
  nplots <- 2*ceiling(nplots/2)
  layout(matrix(1:nplots, nplots/2, 2))
  par(mar = c(4, 4, 1, 1))
  if(type == "trace"){
    for(param in names(x$chains)){
      if(param %in% x$fixed || param %in% c("z", "mu")) next
      if(nrow(x$chains[[param]]) == 1){
        matplot(plot_used_iterations, x$chains[[param]][, used_iterations], type = "l", lty = 1,
                xlab = "iteration", ylab = bquote(.(param)),
                main = paste0("ar = ", get_ar(x$chains[[param]][1, used_iterations])),
                ylim = range(x$chains[[param]][, used_iterations], truth[[param]]), ...)
      } else {
        matplot(plot_used_iterations, t(x$chains[[param]][, used_iterations]), type = "l", lty = 1,
                xlab = "iteration", ylab = bquote(.(param)),
                main = paste0("ar = ", get_ar(x$chains[[param]][1, used_iterations])),
                ylim = range(x$chains[[param]][, used_iterations], truth[[param]]), ...)
      }
      abline(h = truth[[param]], col = 1:length(truth[[param]]), lty = 2)
    }
    if(!("z" %in% x$fixed)){
      z_subset <- seq(1, TIMES, l=min(60, TIMES))
      plot(x$data$times[z_subset], rowMeans(x$chains$z[z_subset, used_iterations]),
           xlab = "time", ylab = "mean", main = "z", ylim = 0:1)
      points(x$data$times[z_subset], truth$z[z_subset],
             pch = 19, cex = 0.8, col = muted("red"))
    }
    return(NULL)
  }
  if(type == "path"){
    if(!("mu" %in% x$fixed)){
      layout(matrix(c(1, 1, 2, 3), 2, 2))
      if(!is.null(background)){
        image(background, col = gray.colors(1e2), asp = 1, bty = "n", ...)
        points(x$chains$mu[, , 1], type = "n", xlab = "x", ylab = "y",
               main = paste0("ar = ", get_ar(x$chains$mu[1, 1, used_iterations])))
      } else {
        plot(x$chains$mu[, , 1], type = "n", xlab = "x", ylab = "y", asp = 1,
             main = paste0("ar = ", get_ar(x$chains$mu[1, 1, used_iterations])), ...)
      }
      lines(truth$mu, col = 2, lwd = 1.5)
      mu_subset <- sort(sample(used_iterations, min(length(used_iterations), 2e2)))
      for(mu_i in mu_subset){
        lines(x$chains$mu[, , mu_i], col = alpha(1, min(1, 5/length(mu_subset))))
      }
      points(x$data$s, pch = 19, cex = 0.5)
      labels <- c("x", "y")
      for(d in 1:2){
        plot(x$data$times, x$chains$mu[, d, 1], type = "n", xlab = "", ylab = labels[d],
             main = "", ...)
        lines(truth$times, truth$mu[, d], col = 2, lwd = 1.5)
        mu_subset <- sort(sample(used_iterations, min(length(used_iterations), 2e2)))
        for(mu_i in mu_subset){
          lines(x$data$times, x$chains$mu[, d, mu_i], col = alpha(1, min(1, 5/length(mu_subset))))
        }
        points(x$data$obstimes, x$data$s[, d], pch = 19, cex = 0.5)
      }
    }
    return(NULL)
  }
  if(type == "tuning"){
    nplots <- length(names(x$tuning_params))
    nplots <- 2*ceiling(nplots/2)
    layout(matrix(1:nplots, nplots/2, 2))
    if(!("tuning_params" %in% names(x))){
      stop("No tuning information found.")
    }
    for(param in names(x$tuning_params)){
      if(param %in% x$fixed || param == "z") next
      if(param == "mu"){
        ars <- sapply(1:(floor(x$N_iterations/x$batch_size)), function(batch_no){
          batch_index <- ((batch_no - 1)*x$batch_size + 1):(batch_no * x$batch_size + 1)
          get_ar(x$chains[[param]][1, 1, batch_index])
        })
        plot(colMeans(x$tuning_params[[param]][, 1:(floor(x$N_iterations/x$batch_size))]), ars,
             col = viridis(sum(!is.na(x$tuning_params[[param]]
                                      [1, 1:(floor(x$N_iterations/x$batch_size))]))),
             ylim = c(0, 1), xlab = "parameter value", main = param, ...)
        abline(h = 0.44, lty = 2)
      } else {
        if(param == "blk1"){
          ars <- sapply(1:(floor(x$N_iterations/x$batch_size)), function(batch_no){
            batch_index <- ((batch_no - 1)*x$batch_size + 1):(batch_no * x$batch_size + 1)
            get_ar(x$chains$beta[1, batch_index])})
        } else if(param == "blk2"){
          ars <- sapply(1:(floor(x$N_iterations/x$batch_size)), function(batch_no){
            batch_index <- ((batch_no - 1)*x$batch_size + 1):(batch_no * x$batch_size + 1)
            get_ar(x$chains$g0[1, batch_index])})
        } else {
          ars <- sapply(1:(floor(x$N_iterations/x$batch_size)), function(batch_no){
            batch_index <- ((batch_no - 1)*x$batch_size + 1):(batch_no * x$batch_size + 1)
            get_ar(x$chains[[param]][1, batch_index])})
        }
        plot(x$tuning_params[[param]][1:(floor(x$N_iterations/x$batch_size))], ars,
             col = viridis(sum(!is.na(x$tuning_params[[param]]))),
             ylim = c(0, 1), xlab = "parameter value", main = param, ...)
        abline(h = 0.23, lty = 2)
      }
    }
    return(NULL)
  }
  if(type == "effects"){
    ## check for W in x or use W if available
    if(!is.null(W)){
      x$data$W <- W
    }
    if(is.null(W_tilde_proj_mat)){
      W_tilde_proj_mat <- diag(nrow(x$chains$theta))
    }
    ## posterior summaries ----
    probs <- c(0.025, 0.05, 0.5, 0.95, 0.975)
    params_df <- as.data.frame(t(rbind(x$chains$beta,
                                       W_tilde_proj_mat %*% x$chains$theta,
                                       x$chains$sigsq_s,
                                       x$chains$sigsq_mu,
                                       x$chains$tausq,
                                       x$chains$alpha,
                                       x$chains$g0,
                                       x$chains$gmax)))
    ## check for names
    if(is.null(X_names)){
      X_names <- paste0("beta", 1:nrow(x$chains$beta))
    }
    if(is.null(W_names)){
      W_names <- paste0("theta", 1:nrow(x$chains$theta))
    }
    names(params_df) <- c(paste0("X_", X_names), paste0("W_", W_names),
                          "sigsq_s", "sigsq_mu", "tausq", "alpha", "g0", "gmax")
    CI_df <- apply(params_df, 2, quantile, probs = probs, na.rm = T)
    CDF_X <- apply(x$chains$beta, 1, function(x) sum(x > 0) / length(x))
    CDF_W <- apply(W_tilde_proj_mat %*% x$chains$theta, 1, function(x) sum(x > 0) / length(x))
    names(CI_df) <- names(params_df)
    ## plot ----
    layout(1)
    par(mar = c(3.7, 2, 2, 1))
    shown_params <- 1:(sum(nrow(x$chains$beta), nrow(x$chains$theta)))
    CDF_shown <- c(CDF_X, CDF_W)
    layout(matrix(1:2, 1, 2), widths = c(1, 1))
    par(mar = c(3.9, 3.8, 2, 1), oma = c(0, 0, 0, 0))
    X_scale_factor <- sqrt(sum(params_df[, 1:nrow(x$chains$beta)]^2) /
                             (length(x$chains$beta) - 1))
    if(X_scale_factor == 0){
      X_scale_factor <- 1
    }
    W_scale_factor <- sqrt(sum(params_df[, 1:nrow(x$chains$theta) +
                                           nrow(x$chains$beta)]^2) /
                             (length(x$chains$theta) - 1))
    if(W_scale_factor == 0){
      W_scale_factor <- 1
    }
    ## X
    plot(1:nrow(x$chains$beta), main = "", type = "n", bty = "n",
         yaxt = "n", xaxt = "n", ylab = "", xlab = "",
         xlim = c(0.5, nrow(x$chains$beta) + 0.5),
         ylim = quantile(c(as.numeric(as.matrix(params_df[, 1:nrow(x$chains$beta)] / X_scale_factor)),
                           as.numeric(as.matrix(params_df[, nrow(x$chains$beta) +
                                                            1:nrow(x$chains$theta)]) /
                                        W_scale_factor)),
                         probs = c(0.001, 0.999)
         )
    )
    abline(h = 0, lty = 2, col = "darkgray")
    for(i in 1:nrow(x$chains$beta)){
      density <- density(params_df[, i] / X_scale_factor)
      norm_density <- density$y / diff(range(density$y)) * 0.33
      i_plot <- i
      polygon(x = c(i_plot - norm_density, i_plot + rev(norm_density)),
              c(density$x, rev(density$x)), col = "gray",
              lwd = 1 + 1.2 * as.numeric(min(CDF_shown[i], 1 - CDF_shown[i]) < 0.05), xpd = F)
    }
    axis_points <- c(-2, -1, 0, 1, 2) * signif(X_scale_factor, 1)
    axis(side = 2, at = axis_points / X_scale_factor, labels = axis_points, xpd = T)
    mtext(text = expression(beta), side = 2, line = 2.5, at = 0)
    text(x = (nrow(x$chains$beta) + 1)/2, y = par()$usr[4] + 0.05 * diff(par()$usr[3:4]),
         labels = "behavior", font = 2, xpd = T)
    text(x = 1:nrow(x$chains$beta),
         y = par()$usr[3] - 0.05 * diff(par()$usr[3:4]), srt = 45, xpd = T,
         labels = X_names, font = 1 + sapply(CDF_shown[1:nrow(x$chains$beta)],
                                             function(x) min(x, 1 - x) < 0.05))
    ## W
    par(mar = c(3.9, 1, 2, 3.8))
    plot(1:nrow(x$chains$theta), main = "", type = "n", bty = "n",
         yaxt = "n", xaxt = "n", ylab = "", xlab = "",
         xlim = c(0.5, nrow(x$chains$theta) + 0.5),
         ylim = quantile(c(as.numeric(as.matrix(params_df[, 1:nrow(x$chains$beta)] / X_scale_factor)),
                           as.numeric(as.matrix(params_df[, nrow(x$chains$beta) + 1:nrow(x$chains$theta)]) /
                                        W_scale_factor)),
                         probs = c(0.001, 0.999)
         )
    )
    abline(h = 0, lty = 2, col = "darkgray")
    for(i in 1:nrow(x$chains$theta)){
      density <- density(params_df[, i + nrow(x$chains$beta)] / W_scale_factor)
      norm_density <- density$y / diff(range(density$y)) * 0.33
      i_plot <- i
      polygon(x = c(i_plot - norm_density, i_plot + rev(norm_density)),
              c(density$x, rev(density$x)), col = "gray",
              lwd = 1 + 1.2 * as.numeric(min(CDF_shown[i + nrow(x$chains$beta)],
                                             1 - CDF_shown[i + nrow(x$chains$beta)]) < 0.05))
    }
    axis_points <- c(-2, -1, 0, 1, 2) * signif(W_scale_factor, 1)
    axis(side = 4, at = axis_points / W_scale_factor, labels = axis_points, xpd = T)
    mtext(text = expression(theta), side = 4, line = 2.5, at = -0.05)
    text(x = (nrow(x$chains$theta) + 1)/2, y = par()$usr[4] + 0.05 * diff(par()$usr[3:4]),
         labels = "recharge", font = 2, xpd = T)
    text(x = 1:nrow(x$chains$theta),
         y = par()$usr[3] - 0.05 * diff(par()$usr[3:4]), srt = 45, xpd = T,
         labels = W_names, font = 1 + sapply(CDF_shown[nrow(x$chains$beta) + 1:nrow(x$chains$theta)],
                                             function(x) min(x, 1 - x) < 0.05))
  }
}
