#' Compute score for model based on mcmc chains and held out observations
#'
#' @param reDyn_mcmc object of class \code{reDyn_mcmc}
#' @param holdout 2-column matrix
#' @param holdout_times vector of times for holdout observations
#' @param seed for reproducibility
#' @param ncores parallelizable across multiple cores
#'
#' @return vector of log_densities for each hold out location
#' @export
get_score <- function(reDyn_mcmc, holdout, holdout_times, ncores = 1, seed = 1){
  set.seed(seed)
  n_holdout <- length(holdout_times)
  holdout_index <- which(reDyn_mcmc$data$times %in% holdout_times)
  mu_holdout <- reDyn_mcmc$chains$mu[holdout_index, , ]
  s_sample <- array(rnorm(n = prod(dim(mu_holdout)), mean = mu_holdout,
                          sd = rep(reDyn_mcmc$chains$sigsq_s,
                                   rep(prod(dim(mu_holdout)[1:2]),
                                       length(reDyn_mcmc$chains$sigsq_s)))^(0.5)),
                    dim = dim(mu_holdout))
  if(ncores > 1){
    log_densities <- log(unlist(parallel::mclapply(X = 1:nrow(holdout), FUN = function(j){
      ks::kde(x = t(s_sample[j, , ]), eval.points = holdout[j, ])$estimate
    }, mc.cores = ncores)))
  } else {
    log_densities <- log(sapply(1:nrow(holdout), function(j){
      ks::kde(x = t(s_sample[j, , ]), eval.points = holdout[j, ])$estimate
    }))
  }
  return(log_densities)
}
