#' print multi-model information
#'
#' @param x object of class \code{reDyn_mcmcs}
#' @param ... Arguments to be passed to methods
#'
#' @return text
#' @export
print.reDyn_mcmcs <- function(x, ...){
  message(paste(length(x) - 2, "total models"))
  message(paste("model fitting began at", x$time_started,
              "and concluded at", x$time_finished))
}
