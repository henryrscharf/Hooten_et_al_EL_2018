## patch times function ----
#' patch times
#'
#' @param times current vector of times
#' @param n number of patches (integer)
#' @param times_bank set from which patches may be drawn
#'
#' @return new vector of times of size \code{length(times) + n}
#' @export
patch_times <- function(times, n = 1, times_bank){
  gap_ids <- which(diff(times) %in% sort(diff(times), decreasing = T)[1:n])
  out <- sapply(gap_ids, function(gap_id){
    gap_int <- times[c(gap_id, gap_id + 1)]
    bank_id <- sum(which.min(times_bank < gap_int[1]), which.max(times_bank > gap_int[2]))/2
    patch <- times_bank[bank_id]
    if(patch %in% times){
      patch <- sample(times_bank[-which(times_bank %in% times)], 1)
    }
    return(patch)
  })
  return(out)
}
## energetics ----
#' get next value of g
#'
#' @param g_tm1 previous value (scalar)
#' @param mu_tm1 previous location (vector of length 2)
#' @param W covariates as \code{RasterStack}, or vector giving \eqn{\mathbf{w}(\mu(t))}
#' @param theta effects (vector with length matching number of layers in \code{W})
#' @param dt time step (scalar)
#' @param alpha factor by which re-charge out-paces depletion (default = 1)
#' @param gmax maximum possible value of g (scalar)
#'
#' @importFrom raster extract
#'
#' @return scalar
#'
#' @export
get_g <- function(g_tm1, mu_tm1 = NULL, W, theta, alpha = 1, dt, gmax = Inf){
  if(is.numeric(W)){
    w_tm1 <- W
  } else {
    w_tm1 <- extract(x = W, y = matrix(mu_tm1, ncol = 2))
  }
  w_tm1_theta <- w_tm1 %*% theta
  if(gmax == Inf){
    return(g_tm1 + alpha * w_tm1_theta * dt)
  }
  if(w_tm1_theta <= 0){
    g <- g_tm1 + w_tm1_theta * dt
  } else {
    g <- g_tm1 + (gmax - g_tm1) * (1 - exp(-alpha*w_tm1_theta/(gmax - g_tm1))) * dt
  }
  return(g)
}

#' get all values of g
#'
#' @param g0 initial value (scalar)
#' @param mu true locations (two-column matrix)
#' @param W covariates as \code{RasterStack}
#' @param theta effects (vector with length matching number of layers in \code{W})
#' @param times times (vector)
#' @param alpha factor by which re-charge out-paces depletion (default = 1)
#' @param gmax maximum possible value of g (scalar)
#'
#' @importFrom raster extract
#'
#' @return scalar
#'
#' @export
get_g_all <- function(g0, mu, W, theta, alpha = 1, times, gmax = Inf){
  TIME <- length(times)
  dt <- diff(times)
  w_t <- extract(x = W, y = matrix(mu, ncol = 2))
  w_t_theta <- w_t %*% theta
  if(gmax == Inf){
    if(alpha == 1){
      return(g0 + c(0, cumsum(w_t_theta[-TIME] * dt)))
    } else {
      return(g0 + c(0, cumsum(w_t_theta[-TIME] * dt * ((w_t_theta[-TIME] <= 0) + alpha * (w_t_theta[-TIME] > 0)))))
    }
  }
  g <- rep(g0, TIME)
  for(t in 2:TIME){
    if(is.na(w_t[t - 1])){
      message("Proposed path extends beyond support of W. [NA in w_t; get_g_all()]")
      return(NA)
    } else if(is.na(w_t_theta[t - 1])){
      message("Proposed path extends beyond support of W. [NA in w_t_theta; get_g_all()]")
      return(NA)
    } else if(w_t_theta[t-1] <= 0){
      g[t] <- g[t-1] + w_t_theta[t-1] * dt[t-1]
    } else {
      g[t] <- g[t-1] + (gmax - g[t-1]) * (1 - exp(-alpha*w_t_theta[t-1]/(gmax - g[t-1]))) * dt[t-1]
    }
    if(g[t] > gmax){
      g[t] <- gmax
    }
  }
  return(g)
}
## gradient ----
#' Gradient of a raster
#'
#' Stolen from \code{ctmcmove}, then fixed problem with radians.
#'
#' @param rasterstack object of class \code{RasterStack} or \code{RasterLayer}
#'
#' @importFrom raster nlayers reclassify terrain
#'
#' @return \code{list}
#' @export
rast_grad <- function(rasterstack){
  if (class(rasterstack) %in% c("RasterStack", "RasterBrick")) {
    n_cells <- rasterstack[[1]]@nrows * rasterstack[[1]]@ncols
    for (k in 1:nlayers(rasterstack)) {
      slope = terrain(rasterstack[[k]], opt = "slope", unit = "tangent")
      aspect = terrain(rasterstack[[k]], opt = "aspect")
      grad.x = -1 * slope * cos(0.5 * pi - aspect)
      grad.x <- reclassify(grad.x, cbind(NA, 0))
      grad.y = -1 * slope * sin(0.5 * pi - aspect)
      grad.y <- reclassify(grad.y, cbind(NA, 0))
    }
    rasterexample = rasterstack[[1]]
  }
  if (class(rasterstack) == "RasterLayer") {
    slope = terrain(rasterstack, opt = "slope", unit = "tangent")
    aspect = terrain(rasterstack, opt = "aspect")
    grad.x = -1 * slope * cos(0.5 * pi - aspect)
    grad.x <- reclassify(grad.x, cbind(NA, 0))
    grad.y = -1 * slope * sin(0.5 * pi - aspect)
    grad.y <- reclassify(grad.y, cbind(NA, 0))
    rasterexample = rasterstack
  }
  list(rast.grad.x = grad.x, rast.grad.y = grad.y)
}

#' get gradient of \eqn{p} at particular location
#'
#' @param mu_tm1 previous location (vector of length 2, or two-column matrix)
#' @param gradX pre-calculated gradient of each covariate in \code{RasterStack} \eqn{X} (output from \code{rast_grad()})
#' @param beta effects (vector with length matching number of layers in \eqn{X})
#' @importFrom raster extract
#'
#' @return two-column matrix
#'
#' @export
get_gradp <- function(mu_tm1, gradX, beta){
  nlayers <- length(gradX)
  if(nlayers > 1){
    gradx_mu_tm1 <- matrix(sapply(1:nlayers, function(layer){
      c(extract(x = gradX[[layer]]$rast.grad.x, y = matrix(mu_tm1, ncol = 2)),
        extract(x = gradX[[layer]]$rast.grad.y, y = matrix(mu_tm1, ncol = 2)))
    }), ncol = nlayers)
    out <- matrix(gradx_mu_tm1 %*% beta, ncol = 2)
  } else {
    out <- matrix(c(extract(x = gradX[[1]]$rast.grad.x, y = matrix(mu_tm1, ncol = 2)),
                    extract(x = gradX[[1]]$rast.grad.y, y = matrix(mu_tm1, ncol = 2))), ncol = 2) * beta
  }
  return(out)
}
