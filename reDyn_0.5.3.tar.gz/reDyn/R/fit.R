## get likelihoods ----
#' compute likelihood conditioned on
#'
#' @param s observed locations (two-column matrix)
#' @param mu true locations (two-column matrix)
#' @param sigsq_mu variance of Brownian motion when \eqn{z(t) = 0} (scalar)
#' @param tausq variance of Brownian motion when \eqn{z(t) = 1} (scalar, default is \code{0}).
#' @param beta effects of covariates, \eqn{X}, on movement when \eqn{z(t) = 1} (vector)
#' @param theta effects of covariates, \eqn{W}, on \eqn{g(t)} (vector)
#' @param alpha factor by which re-charge out-paces depletion (default = 1)
#' @param sigsq_s measurement error variance (scalar)
#' @param g0 initial value of \eqn{g(t)} (scalar)
#' @param gmax maximum possible value of \eqn{g(t)} (scalar)
#' @param times (vector)
#' @param obstimes subset of times (vector)
#' @param gradX pre-calculated gradient of each covariate in \code{RasterStack} \eqn{X} (output from \code{ctmcmove::rast.grad()})
#' @param W covariates effecting \eqn{g(t)} (vector)
#' @importFrom stats dnorm pnorm
#'
#' @return scalar
#' @export
get_ll <- function(s, mu, sigsq_mu, tausq, beta, theta, alpha, sigsq_s,
                   g0, gmax, times, obstimes, gradX, W){
  if(min(c(sigsq_mu, sigsq_s, tausq), na.rm = T) < 0){
    return(-Inf)
  }
  TIMES <- nrow(mu)
  dt <- diff(times)
  mu_t <- mu[-1, ]
  mu_tm1 <- mu[-TIMES, ]
  gradX_path <- get_gradp(mu_tm1 = mu_tm1, gradX = gradX, beta = beta)
  if(sum(is.na(gradX_path)) > 0){
    return(-Inf)
  }
  g <- get_g_all(g0 = g0, mu = mu, W = W, theta = theta, alpha = alpha, times = times, gmax = gmax)
  if(is.na(g[1])){
    message("Proposed path extends beyond support of W. [get_ll()]")
    return(-Inf)
  }
  rho <- pnorm(-g)
  log_density <- sum(dnorm(x = mu_t, mean = mu_tm1 + (gradX_path * dt) * rho[-1],
                           sd = rho[-1] * sqrt(tausq * dt) + (1 - rho[-1]) * sqrt(sigsq_mu * dt), log = T))
  if(sigsq_s == 0){
    log_density_s <- 0
  } else {
    log_density_s <- sum(dnorm(x = s, mean = mu[times %in% obstimes, ], sd = sqrt(sigsq_s), log = T))
  }
  return(log_density + log_density_s)
}


#' compute likelihood conditioned on z
#'
#' @param s observed locations (two-column matrix)
#' @param mu true locations (two-column matrix)
#' @param z true behavior states (vector with length equal to \code{nrow(mu)})
#' @param sigsq_mu variance of Brownian motion when \eqn{z(t) = 0} (scalar)
#' @param tausq variance of Brownian motion when \eqn{z(t) = 1} (scalar, default is \code{0}).
#' @param beta effects of covariates, \eqn{X}, on movement when \eqn{z(t) = 1} (vector)
#' @param sigsq_s measurement error variance (scalar)
#' @param times (vector)
#' @param obstimes subset of times (vector)
#' @param gradX pre-calculated gradient of each covariate in \code{RasterStack} \eqn{X} (output from \code{ctmcmove::rast.grad()})
#' @importFrom stats dnorm
#'
#' @return scalar
#' @export
get_ll_z <- function(s, mu, z, sigsq_mu, tausq, beta,
                     sigsq_s, times, obstimes, gradX){
  if(min(c(sigsq_mu, sigsq_s, tausq), na.rm = T) < 0){
    return(-Inf)
  }
  TIMES <- nrow(mu)
  dt <- diff(times)
  mu_t <- mu[-1, ]
  mu_tm1 <- mu[-TIMES, ]
  gradX_path <- get_gradp(mu_tm1 = mu_tm1, gradX = gradX, beta = beta)
  if(sum(is.na(gradX_path)) > 0){
    message("Proposed path extends beyond support of gradX. [get_ll_z()]")
    return(-Inf)
  }
  log_density <- sum(dnorm(x = mu_t, mean = mu_tm1 + (gradX_path * dt) * z[-1],
                           sd = z[-1] * sqrt(tausq * dt) + (1 - z[-1]) * sqrt(sigsq_mu * dt), log = T))
  if(sigsq_s == 0){
    log_density_s <- 0
    if(sum(s != mu[times %in% obstimes, ]) > 0)
      log_density_s <- -Inf
  } else {
    log_density_s <- sum(dnorm(x = s, mean = mu[times %in% obstimes, ], sd = sqrt(sigsq_s), log = T))
  }
  return(log_density + log_density_s)
}

#' compute the full conditional probabilities that \eqn{\mathbf{z} = 1} for each \eqn{t}
#'
#' @param mu true locations (two-column matrix)
#' @param sigsq_mu variance of Brownian motion when \eqn{z(t) = 0} (scalar)
#' @param tausq variance of Brownian motion when \eqn{z(t) = 1} (scalar, default is \code{0}).
#' @param beta effects of covariates, \eqn{X}, on movement when \eqn{z(t) = 1} (vector)
#' @param theta effects of covariates, \eqn{W}, on \eqn{g(t)} (vector)
#' @param alpha factor by which re-charge out-paces depletion (default = 1)
#' @param g0 initial value of \eqn{g(t)} (scalar)
#' @param gmax maximum possible value of \eqn{g(t)} (scalar)
#' @param times (vector)
#' @param gradX pre-calculated gradient of each covariate in \code{RasterStack} \eqn{X} (output from \code{ctmcmove::rast.grad()})
#' @param W covariates effecting \eqn{g(t)} (vector)
#'
#' @importFrom stats dnorm pnorm
#'
#' @return vector of probabilities
#' @export
get_fc_z <- function(mu, sigsq_mu, tausq, beta, theta, alpha, g0, gmax, times, gradX, W){
  if(min(c(sigsq_mu, tausq), na.rm = T) < 0){
    return(-Inf)
  }
  TIMES <- nrow(mu)
  dt <- diff(times)
  mu_t <- mu[-1, ]
  mu_tm1 <- mu[-TIMES, ]
  g <- get_g_all(g0 = g0, mu = mu, W = W, theta = theta, alpha = alpha, times = times, gmax = gmax)
  if(is.na(g[1])){
    message("Proposed path extends beyond support of W. [get_fc_z()]")
    return(rep(0, nrow(mu)))
  }
  rho <- pnorm(-g)
  gradX_path <- get_gradp(mu_tm1 = mu_tm1, gradX = gradX, beta = beta)
  if(sum(is.na(gradX_path)) > 0){
    return(rep(0, nrow(mu)))
  }
  log_density1 <- rowSums(dnorm(x = mu_t, mean = mu_tm1 + (gradX_path * dt), sd = sqrt(tausq * dt), log = T)) +
    log(rho[-1])
  log_density0 <- rowSums(dnorm(x = mu_t, mean = mu_tm1, sd = sqrt(sigsq_mu * dt), log = T)) +
    log(1-rho[-1])
  log_mean <- (log_density0 + log_density1) / 2
  log_mean[log_mean == -Inf] <- 0
  p1 <- c(rho[1], exp(log_density1 - log_mean) / (exp(log_density1 - log_mean) + exp(log_density0 - log_mean)))
  p1[is.nan(p1)] <- 1
  return(p1)
}

#' get distribution of theta, alpha, g0, and gmax conditioned on z
#'
#' @param mu true locations (two-column matrix)
#' @param theta effects of covariates, \eqn{W}, on \eqn{g(t)} (vector)
#' @param alpha factor by which re-charge out-paces depletion (default = 1)
#' @param z true behavior states (vector with length equal to \code{nrow(mu)})
#' @param g0 initial value of \eqn{g(t)} (scalar)
#' @param gmax maximum possible value of \eqn{g(t)} (scalar)
#' @param times (vector)
#' @param W covariates effecting \eqn{g(t)} (vector)
#'
#' @return scalar
#' @export
get_lfc_theta <- function(theta, alpha, z, mu, g0, gmax, times, W){
  if(alpha < 0 || g0 > gmax){
    return(-Inf)
  }
  TIMES <- nrow(mu)
  dt <- diff(times)
  mu_t <- mu[-1, ]
  mu_tm1 <- mu[-TIMES, ]
  g <- get_g_all(g0 = g0, mu = mu, W = W, theta = theta, alpha = alpha, times = times, gmax = gmax)
  if(is.na(g[1])){
    message("Proposed path extends beyond support of W. [get_lfc_theta()]")
    return(-Inf)
  }
  log_rho <- pnorm(-g, log.p = T)
  one_minus_log_rho <- pnorm(g, log.p = T)
  sum((z * log_rho) + (1 - z) * one_minus_log_rho)
}

#' get log full conditional for \eqn{mu(t)}
#'
#' @param mu_t (2-vector)
#' @param mu_tm1 (2-vector)
#' @param mu_tp1 (2-vector)
#' @param gradX_path (2x2 matrix)
#' @param s_t (2-vector)
#' @param beta (vector) only needed if \code{gradX_path = NULL}
#' @param g (vector) build from \code{mu} that includes \code{mu_t}
#' @param sigsq_mu (positive scalar)
#' @param tausq (positive scalar)
#' @param sigsq_s (positive scalar)
#' @param z (binary vector)
#' @param t_ind (integer)
#' @param times (3-vector)
#' @param gradX pre-calculated gradient of each covariate in \code{RasterStack} \eqn{X} (output from \code{ctmcmove::rast.grad()}). Only needed if \code{gradX_path = NULL}.
#'
#' @return (scalar)
#' @export
get_lfc_mu_t <- function(mu_t, mu_tm1 = NA, mu_tp1 = NA, gradX_path = NULL,
                         s_t = NA, beta, g, sigsq_mu, tausq, sigsq_s = NA,
                         z = NA, t_ind, times, gradX){
  if(min(c(sigsq_mu, sigsq_s, tausq), na.rm = T) < 0){
    return(-Inf)
  }
  dt <- diff(times)
  TIMES <- length(z)
  if(is.null(gradX_path)){
    gradX_path <- get_gradp(mu_tm1 = rbind(mu_tm1, mu_t), gradX = gradX, beta = beta)
  }
  rho <- pnorm(-g)
  sum(dnorm(x = mu_t, mean = mu_tm1 + (gradX_path[1, ] * dt[1]) * z[t_ind - 1],
            sd = z[t_ind - 1] * sqrt(tausq * dt[1]) + (1 - z[t_ind - 1]) * sqrt(sigsq_mu * dt[1]), log = T),
      dnorm(x = mu_tp1, mean = mu_t + (gradX_path[2, ] * dt[2]) * z[t_ind],
            sd = z[t_ind] * sqrt(tausq * dt[2]) + (1 - z[t_ind]) * sqrt(sigsq_mu * dt[2]), log = T),
      dnorm(x = s_t, mean = mu_t, sd = sqrt(sigsq_s), log = T),
      log(rho[t_ind:TIMES]) * z[t_ind:TIMES] + log(1 - rho[t_ind:TIMES]) * (1 - z[t_ind:TIMES]),
      TIMES - t_ind, na.rm = T)
}

#' get log full conditional for \eqn{mu(t)} after integrating out \eqn{}
#'
#' @param mu_t (2-vector)
#' @param mu_tm1 (2-vector)
#' @param mu_tp1 (2-vector)
#' @param gradX_path (2x2 matrix)
#' @param s_t (2-vector)
#' @param beta (vector) only needed if \code{gradX_path = NULL}.
#' @param sigsq_mu (positive scalar)
#' @param tausq (positive scalar)
#' @param sigsq_s (positive scalar)
#' @param rho_t (binary scalar)
#' @param rho_tm1 (binary scalar)
#' @param times (3-vector)
#' @param gradX pre-calculated gradient of each covariate in \code{RasterStack} \eqn{X} (output from \code{ctmcmove::rast.grad()}). Only needed if \code{gradX_path = NULL}.
#'
#' @return (scalar)
#' @export
get_lfc_mu_t_rbz <- function(mu_t, mu_tm1 = NA, mu_tp1 = NA, gradX_path = NULL,
                             s_t = NA, beta, sigsq_mu, tausq, sigsq_s = NA,
                             rho_t = NA, rho_tm1 = NA, times, gradX){
  if(min(c(sigsq_mu, sigsq_s, tausq), na.rm = T) < 0){
    return(-Inf)
  }
  dt <- diff(times)
  if(is.null(gradX_path)){
    gradX_path <- get_gradp(mu_tm1 = rbind(mu_tm1, mu_t), gradX = gradX, beta = beta)
  }
  prod(dnorm(x = mu_t, mean = mu_tm1 + gradX_path[1, ] * dt[1], sd = sqrt(tausq * dt[1])) * rho_tm1 +
         dnorm(x = mu_t, mean = mu_tm1, sd = sqrt(sigsq_mu * dt[1])) * (1 - rho_tm1),
       dnorm(x = mu_tp1, mean = mu_t + gradX_path[2, ] * dt[2], sd = sqrt(tausq * dt[2])) * rho_t +
         dnorm(x = mu_tp1, mean = mu_t, sd = sqrt(sigsq_mu * dt[2])) * (1 - rho_t),
       dnorm(x = s_t, mean = mu_t, sd = sqrt(sigsq_s)), na.rm = T)
}
## sigsq_s (measurement error) [Gibbs sampler] ----
#' sample measurement error variance
#'
#' @param mu true locations (two-column matrix)
#' @param s observed locations (two-column matrix)
#' @param times times at which \code{mu} is realized (vector of length equal to \code{nrow(mu)})
#' @param obstimes times at which \code{s} is observed (vector of length equal to \code{nrow(s)})
#' @param prior_params parameters for inverse-gamma prior (two-vector)
#'
#' @return (scalar)
#' @export
sample_sigsq_s <- function(mu, s, times, obstimes, prior_params = c(0, 0)){
  ld_s <- -0.5 * sum((s - mu[times %in% obstimes, ])^2)
  rinvgamma(1, prior_params[1] + length(obstimes), prior_params[2] - ld_s)
}
