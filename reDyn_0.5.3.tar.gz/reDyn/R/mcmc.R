## mcmc algorithm ----
#' sample from the posterior distribution of model parameters
#'
#' @param initial list with each element the intiial value of a named parameter (vector/matrix/etc.)
#' @param log_priors list with each element the named log-prior function for that parameter
#' @param fixed list of paramters to be fixed at initial values
#' @param N_iterations integer
#' @param data list with named elements: \code{s}, \code{gradX}, \code{W}, \code{times}, \code{obstimes}
#' @param tuning_init initial values for tuning parameters (optional--default is initial values)
#' @param tuning_cov_init initial values for tuning covariances (optional--default is identity matrix)
#' @param tuning_mu_chol logical. Is the matrix provided in \code{tuning_cov_init$mu} the Cholesky decomposition of the covariance matrix? \code{TRUE} results in much faster sampling from the proposal distribution of \code{mu}.
#' @param batch_size used for adaptive tuning
#' @param block_updates logical. Should some parameters be updated in two blocks (\eqn{\boldsymbol\beta, \sigma_\mu^2, \tau^2} and \eqn{\alpha, \boldsymbol\theta, g_0, g_\text{max}}).
#' @param alpha_blk_reps integer giving number of MH sampling reps to perform for \eqn{alpha} (and its associated block) before moving to next iteration.
#' @param save_out_rate integer
#' @param save_out_file location
#' @param verbose_mcmc logical or numeric. Numeric is iteration at which verbose output begins.
#' @param save_tuning_covs logical
#' @param save_gradX logical
#' @param save_W logical
#' @param used_iterations vector of indices to keep from each chain. Primarily available to help mitigate the massive sizes of model fits for densely realized \code{mu}. Default is second half of iterations.
#' @param RBZ logical. Should \eqn{z(t)} be Rao-Blackwell-ized out of the model.
#' @param seed \code{set.seed()} value before doing anything.
#'
#' @importFrom Matrix bdiag
#' @importFrom raster extract
#' @importFrom raster extent
#'
#' @return object of class \code{reDyn_mcmc}
#' @export
reDyn_mcmc <- function(N_iterations, data,
                       initial, log_priors = list(), fixed = list(),
                       tuning_init = list(), tuning_cov_init = list(), tuning_mu_chol = FALSE,
                       batch_size = min(1e2, N_iterations), block_updates = TRUE, alpha_blk_reps = 1,
                       save_out_rate = min(500, N_iterations), save_out_file = NULL,
                       verbose_mcmc = FALSE, save_tuning_covs = FALSE,
                       save_gradX = FALSE, save_W = FALSE,
                       used_iterations = NULL, RBZ = FALSE, seed = 1){
  set.seed(seed)
  if(is.numeric(verbose_mcmc)){
    turn_on_verbose <- verbose_mcmc
    verbose_mcmc <- FALSE
  } else {
    turn_on_verbose <- 0
  }
  ## check data structure ----
  if(nrow(data$s) != length(data$obstimes) || nrow(initial$mu) != length(data$times)){
    stop("Temporal structure does not match movement structure. Check dimensions of data elements.")
  }
  ## make storage + tuning ----
  TIMES <- length(data$times)
  OBSTIMES <- length(data$obstimes)
  obs_ind <- which(data$times %in% data$obstimes)
  batches <- ceiling(N_iterations / batch_size)
  batch_no <- 1
  chains <- lapply(initial, function(param){
    array(param, dim = c(dim(as.array(param)), N_iterations + 1))
  })
  active_names <- names(initial)[-which(names(initial) %in% c('mu', 'z', 'sigsq_s'))]
  tuning_params <- lapply(initial[active_names], function(param){
    out <- abs(mean(as.numeric(param)))
    if(out == 0) out <- 1
    return(c(out, rep(NA, batches - 1)))
  })
  for(param in names(tuning_init)){
    tuning_params[[param]] <- c(tuning_init[[param]], rep(NA, batches - 1))
  }
  for(param in fixed){
    tuning_params[[param]] <- c(0, rep(NA, batches - 1))
  }
  tuning_covs <- lapply(initial[active_names], function(param){
    n_param <- length(param)
    array(diag(n_param), dim = c(n_param, n_param, batches))
  })
  for(param in names(tuning_cov_init)){
    if(param == "mu") next
    tuning_covs[[param]] <- array(tuning_cov_init[[param]],
                                  dim = c(dim(tuning_cov_init[[param]]), batches))
  }
  tuning_covs$mu <- tuning_cov_init$mu
  total_overshoots <- 0
  ## block tuning + covariances
  if(block_updates){
    if(!sum(c("beta", "sigsq_mu", "tausq") %in% fixed) %in% c(0, 3)){
      stop("Cannot do block updates for beta, sigsq_mu, and tausq unless they are fixed/unfixed as a group.")
    }
    # if(!sum(c("alpha", "theta", "g0", "gmax") %in% fixed) %in% c(0, 4)){
    #   stop("Cannot do block updates for alpha, theta, g0, and gmax unless they are fixed/unfixed as a group.")
    # }
    if(sum(c("beta", "sigsq_mu", "tausq") %in% fixed) < 3){
      tuning_params$blk1 <- c(1, rep(NA, batches - 1))
      tuning_covs$blk1 <- array(bdiag(tuning_covs$beta[, , 1] * tuning_params$beta[1]^2,
                                      tuning_covs$sigsq_mu[, , 1] * tuning_params$sigsq_mu[1]^2,
                                      tuning_covs$tausq[, , 1] * tuning_params$tausq[1]^2),
                                dim = c(rep(sum(nrow(tuning_covs$beta), nrow(tuning_covs$sigsq_mu),
                                                nrow(tuning_covs$tausq)), 2), batches))
    }
    tuning_params$beta <- tuning_params$sigsq_mu <- tuning_params$tausq <- NULL
    tuning_covs$beta <- tuning_covs$sigsq_mu <- tuning_covs$tausq <- NULL
    ##
    if(sum(c("alpha", "theta", "g0", "gmax") %in% fixed) < 4){
      tuning_params$blk2 <- c(1, rep(NA, batches - 1))
      tuning_covs$blk2 <- array(bdiag(tuning_covs$alpha[, , 1] * tuning_params$alpha[1]^2,
                                      tuning_covs$theta[, , 1] * tuning_params$theta[1]^2,
                                      tuning_covs$g0[, , 1] * tuning_params$g0[1]^2,
                                      tuning_covs$gmax[, , 1] * tuning_params$gmax[1]^2),
                                dim = c(rep(sum(nrow(tuning_covs$alpha), nrow(tuning_covs$theta),
                                                nrow(tuning_covs$g0), nrow(tuning_covs$gmax)), 2), batches))
    }
    tuning_params$alpha <- tuning_params$theta <- tuning_params$g0 <- tuning_params$gmax <- NULL
    tuning_covs$alpha <- tuning_covs$theta <- tuning_covs$g0 <- tuning_covs$gmax <- NULL
  }
  if(is.null(tuning_cov_init$mu) & !("mu" %in% fixed)){
    message("Updating latent path step by step.")
    tuning_covs$mu <- NULL
    tuning_params$mu <- cbind(rep(tuning_params$mu[1], TIMES), matrix(NA, TIMES, batches - 1))
  }
  ## alpha block tuning
  alpha_blk <- c(1, rep(NA, alpha_blk_reps * N_iterations))
  ## timing ----
  init_time <- Sys.time()
  timing_chkpt <- max(1, floor(N_iterations / 20))
  ## save out ----
  if(is.null(used_iterations)){
    used_iterations <- seq(N_iterations/2, N_iterations, 1)
  }
  if(is.null(save_out_file)){
    save_out_file <- paste(format(init_time, "%Y%m%d_%H%M%S"), "_reDyn_mcmc.RData", sep = "")
  }
  ## blocks loop ----
  if(block_updates & !(RBZ)){
    ld <- matrix(NA, 2, N_iterations + 1)
    ld[1, 1] <- get_ll_z(s = data$s, mu = chains$mu[, , 1], z = chains$z[, 1],
                         sigsq_mu = chains$sigsq_mu[1], tausq = chains$tausq[1],
                         beta = chains$beta[, 1], sigsq_s = chains$sigsq_s[1],
                         times = data$times, obstimes = data$obstimes, gradX = data$gradX)
    ld[2, 1] <- get_lfc_theta(theta = chains$theta[, 1], alpha = chains$alpha[1], z = chains$z[, 1],
                              mu = chains$mu[, , 1], g0 = chains$g0[1], gmax = chains$gmax[1],
                              times = data$times, W = data$W)
    if(min(ld[, 1]) == -Inf){
      stop("Proposed path extends beyond support of covariates (gradX, W). ",
           "Please choose another initial value for mu.")
    }
    for(iter in 2:(N_iterations + 1)){
      if(iter == turn_on_verbose){
        verbose_mcmc <- TRUE
      }
      ## sigsq_s ----
      if("sigsq_s" %in% fixed){
        chains$sigsq_s[iter] <- chains$sigsq_s[iter - 1]
      } else {
        ## Gibbs
        chains$sigsq_s[iter] <-
          sample_sigsq_s(mu = chains$mu[, , iter - 1], s = data$s, times = data$times,
                         obstimes = data$obstimes, prior_params = log_priors$sigsq_s)
        ld[1, iter - 1] <-
          get_ll_z(s = data$s, mu = chains$mu[, , iter - 1], z = chains$z[, iter - 1],
                   sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                   beta = chains$beta[, iter - 1], sigsq_s = chains$sigsq_s[iter],
                   times = data$times, obstimes = data$obstimes, gradX = data$gradX)
        if(verbose_mcmc){
          message("Completed sampling of sigsq_s at iteration ", iter, ".")
        }
      }
      ## mu ----
      if("mu" %in% fixed){
        chains$mu[, , iter] <- chains$mu[, , iter - 1]
      } else {
        if("mu" %in% names(tuning_covs)){
          ## block proposal ----
          for(d in 1:2){
            sample_mu_d <-
              vec_sample_RW(prev = chains$mu[, d, iter - 1],
                            tune_cov = tuning_params$mu[batch_no] * tuning_covs$mu,
                            tune_cov_chol = tuning_mu_chol,
                            get_ld = function(prev){
                              mu <- cbind(prev, chains$mu[, 2, iter - 1])
                              if(d == 2) mu <- cbind(chains$mu[, 1, iter], prev)
                              get_ll_z(mu = mu, s = data$s, z = chains$z[, iter - 1],
                                       sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                                       beta = chains$beta[, iter - 1], sigsq_s = chains$sigsq_s[iter],
                                       times = data$times, obstimes = data$obstimes, gradX = data$gradX)
                            }, log_prior = log_priors$mu, ld_prev = ld[1, iter - 1],
                            verbose_sampler = verbose_mcmc)
            chains$mu[, d, iter] <- sample_mu_d$draw
            ld[1, iter - 1] <- sample_mu_d$ld
          }
        } else {
          ## time loop ----
          mu <- chains$mu[, , iter - 1]
          mu_proposal <- matrix(rnorm(n = 2*TIMES, mean = mu,
                                      sd = sqrt(tuning_params$mu[, batch_no])), ncol = 2)
          check_boundaries <- unique(c(which(mu_proposal[, 1] < extent(data$W)[1]),
                                       which(mu_proposal[, 1] > extent(data$W)[2]),
                                       which(mu_proposal[, 2] < extent(data$W)[3]),
                                       which(mu_proposal[, 2] > extent(data$W)[4])))
          if(verbose_mcmc){
            message("Boundary check yielded check_boundaries = ",
                    paste0(check_boundaries, " "), "\n",
                    "Dimension of mu is ", paste0(dim(mu), " "))
          }
          if(length(check_boundaries) > 0){
            total_overshoots <- total_overshoots + length(check_boundaries)
            mu_proposal[check_boundaries, ] <- mu[check_boundaries, ] ## RW takes a zero-step for these
            if(verbose_mcmc){
              message("Proposed mu is beyond covariate extent at time index ",
                      check_boundaries, " on iteration ", iter, ".")
            }
          }
          gradX_path_proposal <- get_gradp(mu_tm1 = mu_proposal, gradX = data$gradX,
                                           beta = chains$beta[, iter - 1])
          gradX_path_prev <- get_gradp(mu_tm1 = mu, gradX = data$gradX,
                                       beta = chains$beta[, iter - 1])
          gradX_path_proposal_t <- gradX_path_proposal[c(NA, 1), ]
          gradX_path_prev_t <- gradX_path_prev[c(NA, 1), ]
          ## time 1 ----
          g <- get_g_all(g0 = chains$g0[iter - 1], mu = mu, W = data$W,
                         theta = chains$theta[, iter - 1], times = data$times)
          mu_prop_g <- mu
          mu_prop_g[1, ] <- mu_proposal[1, ]
          g_prop <- get_g_all(g0 = chains$g0[iter - 1], mu = mu_prop_g, W = data$W,
                              theta = chains$theta[, iter - 1], times = data$times)
          ld_prev <-
            get_lfc_mu_t(mu_t = mu[1, ], mu_tp1 = mu[2, ], g = g,
                         gradX_path = gradX_path_prev_t, s_t = data$s[1, ],
                         sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                         sigsq_s = chains$sigsq_s[iter], z = chains$z[, iter - 1], t_ind = 1,
                         times = c(NA, data$times[1:2]))
          mu[1, ] <-
            sample_rw(prev = mu[1, ], proposal = mu_proposal[1, ], g = g_prop,
                      get_ld = get_lfc_mu_t, mu_tp1 = mu[2, ], gradX_path = gradX_path_proposal_t,
                      s_t = data$s[1, ], sigsq_mu = chains$sigsq_mu[iter - 1],
                      tausq = chains$tausq[iter - 1], sigsq_s = chains$sigsq_s[iter],
                      z = chains$z[, iter - 1], t_ind = 1, times = c(NA, data$times[1:2]),
                      ld_prev = ld_prev, verbose_sampler = verbose_mcmc)$draw
          ## obstimes ----
          for(t in obs_ind[c(-1, -OBSTIMES)]){
            accept_ind <- mu[t - 1, 1] == mu_proposal[t - 1, 1]
            gradX_path_tm1 <- gradX_path_proposal[t - 1, ] * accept_ind +
              gradX_path_prev[t - 1, ] * (1 - accept_ind)
            gradX_path_proposal_t <- rbind(gradX_path_tm1, gradX_path_proposal[t, ])
            gradX_path_prev_t <- rbind(gradX_path_tm1, gradX_path_prev[t, ])
            g <- get_g_all(g0 = chains$g0[iter - 1], mu = mu, W = data$W,
                           theta = chains$theta[, iter - 1], times = data$times)
            mu_prop_g <- mu
            mu_prop_g[t, ] <- mu_proposal[t, ]
            g_prop <- get_g_all(g0 = chains$g0[iter - 1], mu = mu_prop_g, W = data$W,
                                theta = chains$theta[, iter - 1], times = data$times)
            ld_prev <-
              get_lfc_mu_t(mu_t = mu[t, ], mu_tm1 = mu[t - 1, ], mu_tp1 = mu[t + 1, ], g = g,
                           gradX_path = gradX_path_prev_t, s_t = data$s[which(t == obs_ind), ],
                           sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                           sigsq_s = chains$sigsq_s[iter], z = chains$z[, iter - 1], t_ind = t,
                           times = data$times[(t - 1):(t + 1)])
            mu[t, ] <-
              sample_rw(prev = mu[t, ], proposal = mu_proposal[t, ],
                        get_ld = get_lfc_mu_t, mu_tm1 = mu[t - 1, ], mu_tp1 = mu[t + 1, ], g = g_prop,
                        gradX_path = gradX_path_proposal_t, s_t = data$s[which(t == obs_ind), ],
                        sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                        sigsq_s = chains$sigsq_s[iter], z = chains$z[, iter - 1], t_ind = t,
                        times = data$times[(t - 1):(t + 1)],
                        ld_prev = ld_prev, verbose_sampler = verbose_mcmc)$draw
          }
          ## other times ----
          for(t in (1:TIMES)[-obs_ind]){
            accept_ind <- mu[t - 1, 1] == mu_proposal[t - 1, 1]
            gradX_path_tm1 <- gradX_path_proposal[t - 1, ] * accept_ind +
              gradX_path_prev[t - 1, ] * (1 - accept_ind)
            gradX_path_proposal_t <- rbind(gradX_path_tm1, gradX_path_proposal[t, ])
            gradX_path_prev_t <- rbind(gradX_path_tm1, gradX_path_prev[t, ])
            g <- get_g_all(g0 = chains$g0[iter - 1], mu = mu, W = data$W,
                           theta = chains$theta[, iter - 1], times = data$times)
            mu_prop_g <- mu
            mu_prop_g[t, ] <- mu_proposal[t, ]
            g_prop <- get_g_all(g0 = chains$g0[iter - 1], mu = mu_prop_g, W = data$W,
                                theta = chains$theta[, iter - 1], times = data$times)
            ##
            ld_prev <-
              get_lfc_mu_t(mu_t = mu[t, ], mu_tm1 = mu[t - 1, ], mu_tp1 = mu[t + 1, ], g = g,
                           gradX_path = gradX_path_prev_t, s_t = NA,
                           sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                           z = chains$z[, iter - 1], t_ind = t,
                           times = data$times[(t - 1):(t + 1)])
            mu[t, ] <-
              sample_rw(prev = mu[t, ], proposal = mu_proposal[t, ],
                        get_ld = get_lfc_mu_t, mu_tm1 = mu[t - 1, ], mu_tp1 = mu[t + 1, ], g = g_prop,
                        gradX_path = gradX_path_proposal_t, s_t = NA,
                        sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                        z = chains$z[, iter - 1], t_ind = t,
                        times = data$times[(t - 1):(t + 1)],
                        ld_prev = ld_prev, verbose_sampler = verbose_mcmc)$draw
          }
          ## last time ----
          accept_ind <- mu[TIMES - 1, 1] == mu_proposal[TIMES - 1, 1]
          gradX_path_tm1 <- gradX_path_proposal[TIMES - 1, ] * accept_ind +
            gradX_path_prev[TIMES - 1, ] * (1 - accept_ind)
          gradX_path_proposal_t <- rbind(gradX_path_tm1, gradX_path_proposal[TIMES, ])
          gradX_path_prev_t <- rbind(gradX_path_tm1, gradX_path_prev[TIMES, ])
          g <- get_g_all(g0 = chains$g0[iter - 1], mu = mu, W = data$W,
                         theta = chains$theta[, iter - 1], times = data$times)
          mu_prop_g <- mu
          mu_prop_g[t, ] <- mu_proposal[t, ]
          g_prop <- get_g_all(g0 = chains$g0[iter - 1], mu = mu_prop_g, W = data$W,
                              theta = chains$theta[, iter - 1], times = data$times)
          ##
          ld_prev <-
            get_lfc_mu_t(mu_t = mu[TIMES, ], mu_tm1 = mu[TIMES - 1, ], g = g,
                         gradX_path = gradX_path_prev_t, s_t = data$s[OBSTIMES, ],
                         sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                         sigsq_s = chains$sigsq_s[iter], z = chains$z[, iter - 1], t_ind = TIMES,
                         times = c(data$times[(TIMES - 1):TIMES], NA))
          mu[TIMES, ] <-
            sample_rw(prev = mu[TIMES, ], proposal = mu_proposal[TIMES, ],
                      get_ld = get_lfc_mu_t, mu_tm1 = mu[TIMES - 1, ], g = g_prop,
                      gradX_path = gradX_path_proposal_t, s_t = data$s[OBSTIMES, ],
                      sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                      sigsq_s = chains$sigsq_s[iter], z = chains$z[, iter - 1], t_ind = TIMES,
                      times = c(data$times[(TIMES - 1):TIMES], NA),
                      ld_prev = ld_prev, verbose_sampler = verbose_mcmc)$draw
          ## pass on updated path ----
          # check_boundaries <- c(which(mu[, 1] < extent(data$W)[1]), which(mu[, 1] > extent(data$W)[2]),
          #                       which(mu[, 2] < extent(data$W)[3]), which(mu[, 2] > extent(data$W)[4]))
          # check_boundaries <- unique(c(check_boundaries, which(is.na(extract(x = data$W[[1]], y = mu)))))
          # if(length(check_boundaries) > 0){
          #   stop("Somehow generated path that extends beyond support of W after updating mu.")
          # }
          chains$mu[, , iter] <- mu
        }
        ## update log densities ----
        ld[1, iter - 1] <- get_ll_z(s = data$s, mu = chains$mu[, , iter], z = chains$z[, iter - 1],
                                    sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                                    beta = chains$beta[, iter - 1], sigsq_s = chains$sigsq_s[iter],
                                    times = data$times, obstimes = data$obstimes, gradX = data$gradX)
        ld[2, iter - 1] <- get_lfc_theta(theta = chains$theta[, iter - 1], alpha = chains$alpha[iter - 1],
                                         z = chains$z[, iter - 1], mu = chains$mu[, , iter],
                                         g0 = chains$g0[iter - 1], gmax = chains$gmax[iter - 1],
                                         times = data$times, W = data$W)
      }
      ## check for negative infinite ll ----
      if(min(ld[, iter - 1]) == -Inf){
        stop("Negative inifinte log likelihood somehow achieved btw mu and z.")
      }
      ## z ----
      if("z" %in% fixed){
        chains$z[, iter] <- chains$z[, iter - 1]
      } else {
        pr_zeq1 <-
          get_fc_z(mu = chains$mu[, , iter], sigsq_mu = chains$sigsq_mu[iter - 1],
                   tausq = chains$tausq[iter - 1], beta = chains$beta[, iter - 1],
                   theta = chains$theta[, iter - 1], alpha = chains$alpha[iter - 1],
                   g0 = chains$g0[iter - 1], gmax = chains$gmax[iter - 1],
                   times = data$times, gradX = data$gradX, W = data$W)
        chains$z[, iter] <- sapply(pr_zeq1, function(prob){
          sample(x = 1:0, size = 1, prob = c(prob, 1-prob))
        })
      }
      ld[1, iter - 1] <- get_ll_z(s = data$s, mu = chains$mu[, , iter], z = chains$z[, iter],
                                  sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                                  beta = chains$beta[, iter - 1], sigsq_s = chains$sigsq_s[iter],
                                  times = data$times, obstimes = data$obstimes, gradX = data$gradX)
      ld[2, iter - 1] <- get_lfc_theta(theta = chains$theta[, iter - 1], alpha = chains$alpha[iter - 1],
                                       z = chains$z[, iter], mu = chains$mu[, , iter],
                                       g0 = chains$g0[iter - 1], gmax = chains$gmax[iter - 1],
                                       times = data$times, W = data$W)
      ## check for negative infinite ll ----
      if(min(ld[, iter - 1]) == -Inf){
        stop("Negative inifinte log likelihood somehow achieved btw z and blk1.")
      }
      ## block 1 (beta, sigsq_mu, tausq) ----
      chains$beta[, iter] <- chains$beta[, iter - 1]
      chains$sigsq_mu[iter] <- chains$sigsq_mu[iter - 1]
      chains$tausq[iter] <- chains$tausq[iter - 1]
      if(sum(c("beta", "sigsq_mu", "tausq") %in% fixed) < 3){
        block_sample <-
          vec_sample_RW(prev = c(chains$beta[, iter - 1], chains$sigsq_mu[iter - 1], chains$tausq[iter - 1]),
                        tune_cov = tuning_params$blk1[batch_no] * tuning_covs$blk1[, , batch_no],
                        get_ld = function(prev){
                          n_prev <- length(prev)
                          get_ll_z(beta = prev[1:(n_prev - 2)], s = data$s,
                                   sigsq_mu = prev[n_prev - 1], tausq = prev[n_prev],
                                   mu = chains$mu[, , iter], z = chains$z[, iter],
                                   sigsq_s = chains$sigsq_s[iter], times = data$times,
                                   obstimes = data$obstimes, gradX = data$gradX)
                        },
                        log_prior = function(blk1){
                          n_blk1 <- length(blk1)
                          log_priors$beta(blk1[1:(n_blk1 - 2)]) +
                            log_priors$sigsq_mu(blk1[n_blk1 - 1]) +
                            log_priors$tausq(blk1[n_blk1])
                        },
                        ld_prev = ld[1, iter - 1], verbose_sampler = verbose_mcmc)
        chains$beta[, iter] <- block_sample$draw[1:nrow(chains$beta)]
        chains$sigsq_mu[iter] <- block_sample$draw[nrow(chains$beta) + 1]
        chains$tausq[iter] <- block_sample$draw[nrow(chains$beta) + 2]
        ld[1, iter - 1] <- block_sample$ld
      }
      ## check for negative infinite ll ----
      if(min(ld[, iter - 1]) == -Inf){
        stop("Negative inifinte log likelihood somehow achieved btw blk1 and blk2.")
      }
      ## block 2 (alpha, theta, g0, gmax) ----
      chains$alpha[iter] <- chains$alpha[iter - 1]
      chains$theta[, iter] <- chains$theta[, iter - 1]
      chains$g0[iter] <- chains$g0[iter - 1]
      chains$gmax[iter] <- chains$gmax[iter - 1]
      if(sum(c("alpha", "theta", "g0", "gmax") %in% fixed) < 4){
        for(rep in 1:alpha_blk_reps){
          block_sample <-
            vec_sample_RW(prev = c(chains$alpha[iter], chains$theta[, iter],
                                   chains$g0[iter], chains$gmax[iter]),
                          tune_cov = tuning_params$blk2[batch_no] * tuning_covs$blk2[, , batch_no],
                          get_ld = function(prev){
                            n_prev <- length(prev)
                            get_lfc_theta(alpha = prev[1], theta = prev[2:(n_prev - 2)],
                                          z = chains$z[, iter], mu = chains$mu[, , iter],
                                          g0 = prev[n_prev - 1], gmax = prev[n_prev],
                                          times = data$times, W = data$W)
                          },
                          log_prior = function(blk2){
                            n_blk2 <- length(blk2)
                            log_priors$alpha(blk2[1]) +
                              log_priors$theta(blk2[2:(n_blk2 - 2)]) +
                              log_priors$g0(blk2[n_blk2 - 1]) +
                              log_priors$gmax(blk2[n_blk2])
                          },
                          ld_prev = ld[2, iter - 1], verbose_sampler = verbose_mcmc)
          alpha_blk[alpha_blk_reps * (iter - 2) + rep + 1] <-
            alpha_blk[alpha_blk_reps * (iter - 2) + rep] * (2 * (ld[2, iter - 1] == block_sample$ld) - 1)
          chains$alpha[iter] <- block_sample$draw[1]
          chains$theta[, iter] <- block_sample$draw[1:nrow(chains$theta) + 1]
          chains$g0[iter] <- block_sample$draw[nrow(chains$theta) + 2]
          chains$gmax[iter] <- block_sample$draw[nrow(chains$theta) + 3]
          ld[2, iter - 1] <- block_sample$ld
        }
      }
      ## ----
      ## ld ----
      ld[, iter] <- ld[, iter - 1]
      ## tuning ----
      if(iter %% batch_size == 1 & iter < N_iterations + 1){
        if(verbose_mcmc){
          message("Starting tuning after iteration ", iter, ". \n",
                  "batch_no = ", batch_no, "\n",
                  "Beginning block 1.")
        }
        batch_no = batch_no + 1
        ## block 1 (beta, sigsq_mu, tausq) ----
        if(sum(c("beta", "sigsq_mu", "tausq") %in% fixed) < 3){
          tuning_update_stuff <-
            vec_update_TUNING(batch = rbind(chains$beta[, (iter - batch_size):iter],
                                            chains$sigsq_mu[, (iter - batch_size):iter],
                                            chains$tausq[, (iter - batch_size):iter]),
                              batch_no = batch_no - 1, tuning_param = tuning_params$blk1[batch_no - 1],
                              tune_cov = tuning_covs$blk1[, , batch_no - 1])
          tuning_covs$blk1[, , batch_no] <- tuning_update_stuff$tune_cov
          tuning_params$blk1[batch_no] <- tuning_update_stuff$param
        }
        ## block 2 (alpha, theta, g0, gmax) ----
        if(verbose_mcmc){
          message("Beginning block 2.")
        }
        if(sum(c("alpha", "theta", "g0", "gmax") %in% fixed) < 4){
          tuning_update_stuff <-
            vec_update_TUNING(batch = rbind(chains$alpha[(iter - batch_size):iter],
                                            chains$theta[, (iter - batch_size):iter],
                                            chains$g0[(iter - batch_size):iter],
                                            chains$gmax[(iter - batch_size):iter]),
                              batch_no = batch_no - 1, tuning_param = tuning_params$blk2[batch_no - 1],
                              tune_cov = tuning_covs$blk2[, , batch_no - 1])
          tuning_covs$blk2[, , batch_no] <- tuning_update_stuff$tune_cov
          # tuning_params$blk2[batch_no] <- tuning_update_stuff$param
          tuning_params$blk2[batch_no] <-
            update_tuning(batch = alpha_blk[(alpha_blk_reps * ((iter - 1) - batch_size) + 1):
                                              (alpha_blk_reps * (iter - 1) + 1)],
                          batch_no = batch_no - 1, tuning_param = tuning_params$blk2[batch_no - 1], target = 0.23)
        }
        ## mu ----
        if(verbose_mcmc){
          message("Beginning mu.")
        }
        if(!("mu" %in% fixed)){
          if("mu" %in% names(tuning_covs)){
            tuning_params[["mu"]][batch_no] <-
              update_tuning(batch = chains[["mu"]][1, 1, (iter - batch_size):iter], target = 0.23,
                            batch_no = batch_no - 1, tuning_param = tuning_params[["mu"]][batch_no - 1])
          } else {
            for(t in 1:TIMES){
              tuning_params$mu[t, batch_no] <-
                update_tuning(batch = chains$mu[t, 1, (iter - batch_size):iter], target = 0.44,
                              batch_no = batch_no - 1, tuning_param = tuning_params$mu[t, batch_no - 1])
            }
          }
        }
        if(verbose_mcmc){
          message("All done.")
        }
      }
      ## timing ----
      if(iter %% timing_chkpt == 1){
        timing <- Sys.time() - init_time
        message(paste("iteration ", iter-1, " (", floor((iter - 1) / N_iterations * 100), "%)",
                      " [", signif(timing, 5), " ", attr(timing, "units"), "]", sep = ""))
      }
      ## save out ----
      if((iter %% save_out_rate == 1 & !is.na(save_out_file)) || iter == N_iterations + 1){
        out_partial <- list("chains" = chains, "initial" = initial,
                            "data" = data[!(names(data) %in% c("W", "gradX"))],
                            "N_iterations" = N_iterations,
                            "batch_size" = batch_size, "log_priors" = log_priors, "fixed" = fixed,
                            "tuning_params" = tuning_params, "total_overshoots" = total_overshoots,
                            "completed_iterations" = iter - 1,
                            "time_started" = format(init_time, "%Y%m%d_%H%M%S"),
                            "time_finished" = format(Sys.time(), "%Y%m%d_%H%M%S")
        )
        if(save_tuning_covs){
          out_partial$tuning_covs = tuning_covs
        }
        if(save_gradX){
          out_partial$data$gradX <- data$gradX
        }
        if(save_W){
          out_partial$data$W <- data$W
        }
        class(out_partial) <- "reDyn_mcmc"
        if(iter < N_iterations + 1){
          save(out_partial, file = save_out_file)
        }
      }
    }
  }
  ## blocks loop w/RBZ ----
  else if(block_updates & RBZ){
    ld <- rep(NA, N_iterations + 1)
    ld[1] <- get_ll(s = data$s, mu = chains$mu[, , 1], sigsq_mu = chains$sigsq_mu[1],
                    tausq = chains$tausq[1], beta = chains$beta[, 1], theta = chains$theta[, 1],
                    alpha = chains$alpha[1], sigsq_s = chains$sigsq_s[1], g0 = chains$g0[1],
                    gmax = chains$gmax[1], times = data$times, obstimes = data$obstimes,
                    gradX = data$gradX, W = data$W)
    if(ld[1] == -Inf){
      stop("Proposed path extends beyond support of covariates (gradX, W). ",
           "Please choose another initial value for mu.")
    }
    for(iter in 2:(N_iterations + 1)){
      if(iter == turn_on_verbose){
        verbose_mcmc <- TRUE
      }
      ## sigsq_s ----
      if("sigsq_s" %in% fixed){
        chains$sigsq_s[iter] <- chains$sigsq_s[iter - 1]
      } else {
        ## Gibbs
        chains$sigsq_s[iter] <-
          sample_sigsq_s(mu = chains$mu[, , iter - 1], s = data$s, times = data$times,
                         obstimes = data$obstimes, prior_params = log_priors$sigsq_s)
        ld[iter - 1] <-
          get_ll(s = data$s, mu = chains$mu[, , iter - 1], sigsq_mu = chains$sigsq_mu[iter - 1],
                 tausq = chains$tausq[iter - 1], beta = chains$beta[, iter - 1], theta = chains$theta[, iter - 1],
                 alpha = chains$alpha[iter - 1], sigsq_s = chains$sigsq_s[iter], g0 = chains$g0[iter - 1],
                 gmax = chains$gmax[iter - 1], times = data$times, obstimes = data$obstimes,
                 gradX = data$gradX, W = data$W)
        if(verbose_mcmc){
          message("Completed sampling of sigsq_s at iteration ", iter, ".")
        }
      }
      ## mu ----
      if("mu" %in% fixed){
        chains$mu[, , iter] <- chains$mu[, , iter - 1]
      } else {
        if("mu" %in% names(tuning_covs)){
          ## block proposal ----
          for(d in 1:2){
            sample_mu_d <-
              vec_sample_RW(prev = chains$mu[, d, iter - 1],
                            tune_cov = tuning_params$mu[batch_no] * tuning_covs$mu,
                            tune_cov_chol = tuning_mu_chol,
                            get_ld = function(prev){
                              mu <- cbind(prev, chains$mu[, 2, iter - 1])
                              if(d == 2) mu <- cbind(chains$mu[, 1, iter], prev)
                              get_ll_z(mu = mu, s = data$s, z = chains$z[, iter - 1],
                                       sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                                       beta = chains$beta[, iter - 1], sigsq_s = chains$sigsq_s[iter],
                                       times = data$times, obstimes = data$obstimes, gradX = data$gradX)
                            }, log_prior = log_priors$mu, ld_prev = ld[1, iter - 1],
                            verbose_sampler = verbose_mcmc)
            chains$mu[, d, iter] <- sample_mu_d$draw
            ld[1, iter - 1] <- sample_mu_d$ld
          }
        } else {
          ## time loop ----
          mu <- chains$mu[, , iter - 1]
          mu_proposal <- matrix(rnorm(n = 2*TIMES, mean = mu,
                                      sd = sqrt(tuning_params$mu[, batch_no])), ncol = 2)
          check_boundaries <- unique(c(which(mu_proposal[, 1] < extent(data$W)[1]),
                                       which(mu_proposal[, 1] > extent(data$W)[2]),
                                       which(mu_proposal[, 2] < extent(data$W)[3]),
                                       which(mu_proposal[, 2] > extent(data$W)[4])))
          if(verbose_mcmc){
            message("Boundary check yielded check_boundaries = ",
                    paste0(check_boundaries, " "), "\n",
                    "Dimension of mu is ", paste0(dim(mu), " "))
          }
          if(length(check_boundaries) > 0){
            total_overshoots <- total_overshoots + length(check_boundaries)
            mu_proposal[check_boundaries, ] <- mu[check_boundaries, ] ## RW takes a zero-step for these
            if(verbose_mcmc){
              message("Proposed mu is beyond covariate extent at time index ",
                      check_boundaries, " on iteration ", iter, ".")
            }
          }
          gradX_path_proposal <- get_gradp(mu_tm1 = mu_proposal, gradX = data$gradX,
                                           beta = chains$beta[, iter - 1])
          gradX_path_prev <- get_gradp(mu_tm1 = mu, gradX = data$gradX,
                                       beta = chains$beta[, iter - 1])
          gradX_path_proposal_t <- gradX_path_proposal[c(NA, 1), ]
          gradX_path_prev_t <- gradX_path_prev[c(NA, 1), ]
          W_proposal_path <- extract(x = data$W, y = mu_proposal)
          W_prev_path <- extract(x = data$W, y = mu)
          ## time 1 ----
          g_t <- chains$g0[iter - 1]
          ld_prev <-
            get_lfc_mu_t_rbz(mu_t = mu[1, ], mu_tp1 = mu[2, ],
                             gradX_path = gradX_path_prev_t, s_t = data$s[1, ],
                             sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                             sigsq_s = chains$sigsq_s[iter], rho_t = 1 - pnorm(g_t),
                             times = c(NA, data$times[1:2]))
          mu[1, ] <-
            sample_rw(prev = mu[1, ], proposal = mu_proposal[1, ],
                      get_ld = get_lfc_mu_t_rbz, mu_tp1 = mu[2, ], gradX_path = gradX_path_proposal_t,
                      s_t = data$s[1, ], sigsq_mu = chains$sigsq_mu[iter - 1],
                      tausq = chains$tausq[iter - 1], sigsq_s = chains$sigsq_s[iter],
                      rho_t = 1 - pnorm(g_t), times = c(NA, data$times[1:2]),
                      ld_prev = ld_prev, verbose_sampler = verbose_mcmc)$draw
          ## middle times ----
          for(t in 2:(TIMES - 1)){
            accept_ind <- mu[t - 1, 1] == mu_proposal[t - 1, 1]
            w_tm1 <- W_proposal_path[t - 1, ] * accept_ind + W_prev_path[t - 1, ] * (1 - accept_ind)
            g_tm1 <- g_t
            g_t <- as.numeric(get_g(g_tm1 = g_tm1, W = w_tm1, theta = chains$theta[, iter - 1],
                                    alpha = chains$alpha[iter - 1], gmax = chains$gmax[iter - 1],
                                    dt = diff(data$times[(t - 1):t])))
            gradX_path_tm1 <- gradX_path_proposal[t - 1, ] * accept_ind +
              gradX_path_prev[t - 1, ] * (1 - accept_ind)
            gradX_path_proposal_t <- rbind(gradX_path_tm1, gradX_path_proposal[t, ])
            gradX_path_prev_t <- rbind(gradX_path_tm1, gradX_path_prev[t, ])
            ## obstimes ----
            if(t %in% obs_ind){
              ld_prev <-
                get_lfc_mu_t_rbz(mu_t = mu[t, ], mu_tm1 = mu[t - 1, ], mu_tp1 = mu[t + 1, ],
                                 gradX_path = gradX_path_prev_t, s_t = data$s[which(t == obs_ind), ],
                                 sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                                 sigsq_s = chains$sigsq_s[iter], rho_t = 1 - pnorm(g_t),
                                 rho_tm1 = 1 - pnorm(g_tm1), times = data$times[(t - 1):(t + 1)])
              mu[t, ] <-
                sample_rw(prev = mu[t, ], proposal = mu_proposal[t, ],
                          get_ld = get_lfc_mu_t_rbz, mu_tm1 = mu[t - 1, ], mu_tp1 = mu[t + 1, ],
                          gradX_path = gradX_path_proposal_t, s_t = data$s[which(t == obs_ind), ],
                          sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                          sigsq_s = chains$sigsq_s[iter], rho_t = 1 - pnorm(g_t),
                          rho_tm1 = 1 - pnorm(g_tm1), times = data$times[(t - 1):(t + 1)],
                          ld_prev = ld_prev, verbose_sampler = verbose_mcmc)$draw
            }
            ## other times ----
            else {
              ld_prev <-
                get_lfc_mu_t_rbz(mu_t = mu[t, ], mu_tm1 = mu[t - 1, ], mu_tp1 = mu[t + 1, ],
                                 gradX_path = gradX_path_prev_t, sigsq_mu = chains$sigsq_mu[iter - 1],
                                 tausq = chains$tausq[iter - 1], sigsq_s = chains$sigsq_s[iter],
                                 rho_t = 1 - pnorm(g_t), rho_tm1 = 1 - pnorm(g_tm1),
                                 times = data$times[(t - 1):(t + 1)])
              mu[t, ] <-
                sample_rw(prev = mu[t, ], proposal = mu_proposal[t, ],
                          get_ld = get_lfc_mu_t_rbz, mu_tm1 = mu[t - 1, ], mu_tp1 = mu[t + 1, ],
                          gradX_path = gradX_path_proposal_t, sigsq_mu = chains$sigsq_mu[iter - 1],
                          tausq = chains$tausq[iter - 1], sigsq_s = chains$sigsq_s[iter],
                          rho_t = 1 - pnorm(g_t), rho_tm1 = 1 - pnorm(g_tm1),
                          times = data$times[(t - 1):(t + 1)], ld_prev = ld_prev,
                          verbose_sampler = verbose_mcmc)$draw
            }
          }
          ## last time ----
          accept_ind <- mu[TIMES - 1, 1] == mu_proposal[TIMES - 1, 1]
          w_tm1 <- W_proposal_path[TIMES - 1, ] * accept_ind + W_prev_path[TIMES - 1, ] * (1 - accept_ind)
          g_tm1 <- g_t
          g_t <- as.numeric(get_g(g_tm1 = g_tm1, W = w_tm1,
                                  theta = chains$theta[, iter - 1], alpha = chains$alpha[iter - 1],
                                  dt = diff(data$times[(TIMES - 1):TIMES]), gmax = chains$gmax[iter - 1]))
          gradX_path_tm1 <- gradX_path_proposal[TIMES - 1, ] * accept_ind +
            gradX_path_prev[TIMES - 1, ] * (1 - accept_ind)
          gradX_path_proposal_t <- rbind(gradX_path_tm1, gradX_path_proposal[TIMES, ])
          gradX_path_prev_t <- rbind(gradX_path_tm1, gradX_path_prev[TIMES, ])
          ld_prev <-
            get_lfc_mu_t_rbz(mu_t = mu[TIMES, ], mu_tm1 = mu[TIMES - 1, ],
                             gradX_path = gradX_path_prev_t, s_t = data$s[OBSTIMES, ],
                             sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                             sigsq_s = chains$sigsq_s[iter], rho_t = 1 - pnorm(g_t),
                             rho_tm1 = 1 - pnorm(g_tm1), times = c(data$times[(TIMES - 1):TIMES], NA))
          mu[TIMES, ] <-
            sample_rw(prev = mu[TIMES, ], proposal = mu_proposal[TIMES, ],
                      get_ld = get_lfc_mu_t_rbz, mu_tm1 = mu[TIMES - 1, ],
                      gradX_path = gradX_path_proposal_t, s_t = data$s[OBSTIMES, ],
                      sigsq_mu = chains$sigsq_mu[iter - 1], tausq = chains$tausq[iter - 1],
                      sigsq_s = chains$sigsq_s[iter], rho_t = 1 - pnorm(g_t),
                      rho_tm1 = 1 - pnorm(g_tm1), times = c(data$times[(TIMES - 1):TIMES], NA),
                      ld_prev = ld_prev, verbose_sampler = verbose_mcmc)$draw
          chains$mu[, , iter] <- mu
        }
        ## update log densities ----
        ld[iter - 1] <- get_ll(s = data$s, mu = chains$mu[, , iter], sigsq_mu = chains$sigsq_mu[iter - 1],
                               tausq = chains$tausq[iter - 1], beta = chains$beta[, iter - 1],
                               theta = chains$theta[, iter - 1], alpha = chains$alpha[iter - 1],
                               sigsq_s = chains$sigsq_s[iter], g0 = chains$g0[iter - 1],
                               gmax = chains$gmax[iter - 1], times = data$times, obstimes = data$obstimes,
                               gradX = data$gradX, W = data$W)
      }
      ## check for negative infinite ll ----
      if(min(ld[iter - 1]) == -Inf){
        stop("Negative inifinte log likelihood somehow achieved btw mu and block 1.")
      }
      ## block 1 (beta, sigsq_mu, tausq) ----
      chains$beta[, iter] <- chains$beta[, iter - 1]
      chains$sigsq_mu[iter] <- chains$sigsq_mu[iter - 1]
      chains$tausq[iter] <- chains$tausq[iter - 1]
      if(sum(c("beta", "sigsq_mu", "tausq") %in% fixed) < 3){
        block_sample <-
          vec_sample_RW(prev = c(chains$beta[, iter - 1], chains$sigsq_mu[iter - 1], chains$tausq[iter - 1]),
                        tune_cov = tuning_params$blk1[batch_no] * tuning_covs$blk1[, , batch_no],
                        get_ld = function(prev){
                          n_prev <- length(prev)
                          get_ll(beta = prev[1:(n_prev - 2)], s = data$s, sigsq_mu = prev[n_prev - 1],
                                 tausq = prev[n_prev], mu = chains$mu[, , iter], theta = chains$theta[, iter - 1],
                                 alpha = chains$alpha[iter - 1], sigsq_s = chains$sigsq_s[iter],
                                 g0 = chains$g0[iter - 1], gmax = chains$gmax[iter - 1],
                                 times = data$times, obstimes = data$obstimes, gradX = data$gradX, W = data$W)
                        },
                        log_prior = function(blk1){
                          n_blk1 <- length(blk1)
                          log_priors$beta(blk1[1:(n_blk1 - 2)]) +
                            log_priors$sigsq_mu(blk1[n_blk1 - 1]) +
                            log_priors$tausq(blk1[n_blk1])
                        },
                        ld_prev = ld[iter - 1], verbose_sampler = verbose_mcmc)
        chains$beta[, iter] <- block_sample$draw[1:nrow(chains$beta)]
        chains$sigsq_mu[iter] <- block_sample$draw[nrow(chains$beta) + 1]
        chains$tausq[iter] <- block_sample$draw[nrow(chains$beta) + 2]
        ld[iter - 1] <- block_sample$ld
      }
      ## check for negative infinite ll ----
      if(min(ld[iter - 1]) == -Inf){
        stop("Negative inifinte log likelihood somehow achieved btw blk1 and blk2.")
      }
      ## block 2 (alpha, theta, g0, gmax) ----
      chains$alpha[iter] <- chains$alpha[iter - 1]
      chains$theta[, iter] <- chains$theta[, iter - 1]
      chains$g0[iter] <- chains$g0[iter - 1]
      chains$gmax[iter] <- chains$gmax[iter - 1]
      if(sum(c("alpha", "theta", "g0", "gmax") %in% fixed) < 4){
        for(rep in 1:alpha_blk_reps){
          block_sample <-
            vec_sample_RW(prev = c(chains$alpha[iter], chains$theta[, iter],
                                   chains$g0[iter], chains$gmax[iter]),
                          tune_cov = tuning_params$blk2[batch_no] * tuning_covs$blk2[, , batch_no],
                          get_ld = function(prev){
                            n_prev <- length(prev)
                            get_ll(s = data$s, sigsq_mu = chains$sigsq_mu[iter], tausq = chains$tausq[iter],
                                   beta = chains$beta[, iter], alpha = prev[1], theta = prev[2:(n_prev - 2)],
                                   sigsq_s = chains$sigsq_s[iter], mu = chains$mu[, , iter],
                                   g0 = prev[n_prev - 1], gmax = prev[n_prev], times = data$times,
                                   obstimes = data$obstimes, gradX = data$gradX, W = data$W)
                          },
                          log_prior = function(blk2){
                            n_blk2 <- length(blk2)
                            log_priors$alpha(blk2[1]) +
                              log_priors$theta(blk2[2:(n_blk2 - 2)]) +
                              log_priors$g0(blk2[n_blk2 - 1]) +
                              log_priors$gmax(blk2[n_blk2])
                          },
                          ld_prev = ld[iter - 1], verbose_sampler = verbose_mcmc)
          alpha_blk[alpha_blk_reps * (iter - 2) + rep + 1] <-
            alpha_blk[alpha_blk_reps * (iter - 2) + rep] * (2 * (ld[iter - 1] == block_sample$ld) - 1)
          chains$alpha[iter] <- block_sample$draw[1]
          chains$theta[, iter] <- block_sample$draw[1:nrow(chains$theta) + 1]
          chains$g0[iter] <- block_sample$draw[nrow(chains$theta) + 2]
          chains$gmax[iter] <- block_sample$draw[nrow(chains$theta) + 3]
          ld[iter - 1] <- block_sample$ld
        }
      }
      ## ----
      ## ld ----
      ld[iter] <- ld[iter - 1]
      ## tuning ----
      if(iter %% batch_size == 1 & iter < N_iterations + 1){
        if(verbose_mcmc){
          message("Starting tuning after iteration ", iter, ". \n",
                  "batch_no = ", batch_no, "\n",
                  "Beginning block 1.")
        }
        batch_no = batch_no + 1
        ## block 1 (beta, sigsq_mu, tausq) ----
        if(sum(c("beta", "sigsq_mu", "tausq") %in% fixed) < 3){
          tuning_update_stuff <-
            vec_update_TUNING(batch = rbind(chains$beta[, (iter - batch_size):iter],
                                            chains$sigsq_mu[, (iter - batch_size):iter],
                                            chains$tausq[, (iter - batch_size):iter]),
                              batch_no = batch_no - 1, tuning_param = tuning_params$blk1[batch_no - 1],
                              tune_cov = tuning_covs$blk1[, , batch_no - 1])
          tuning_covs$blk1[, , batch_no] <- tuning_update_stuff$tune_cov
          tuning_params$blk1[batch_no] <- tuning_update_stuff$param
        }
        ## block 2 (alpha, theta, g0, gmax) ----
        if(verbose_mcmc){
          message("Beginning block 2.")
        }
        if(sum(c("alpha", "theta", "g0", "gmax") %in% fixed) < 4){
          tuning_update_stuff <-
            vec_update_TUNING(batch = rbind(chains$alpha[(iter - batch_size):iter],
                                            chains$theta[, (iter - batch_size):iter],
                                            chains$g0[(iter - batch_size):iter],
                                            chains$gmax[(iter - batch_size):iter]),
                              batch_no = batch_no - 1, tuning_param = tuning_params$blk2[batch_no - 1],
                              tune_cov = tuning_covs$blk2[, , batch_no - 1])
          tuning_covs$blk2[, , batch_no] <- tuning_update_stuff$tune_cov
          # tuning_params$blk2[batch_no] <- tuning_update_stuff$param
          tuning_params$blk2[batch_no] <-
            update_tuning(batch = alpha_blk[(alpha_blk_reps * ((iter - 1) - batch_size) + 1):
                                              (alpha_blk_reps * (iter - 1) + 1)],
                          batch_no = batch_no - 1, tuning_param = tuning_params$blk2[batch_no - 1], target = 0.23)
        }
        ## mu ----
        if(verbose_mcmc){
          message("Beginning mu.")
        }
        if(!("mu" %in% fixed)){
          if("mu" %in% names(tuning_covs)){
            tuning_params[["mu"]][batch_no] <-
              update_tuning(batch = chains[["mu"]][1, 1, (iter - batch_size):iter], target = 0.23,
                            batch_no = batch_no - 1, tuning_param = tuning_params[["mu"]][batch_no - 1])
          } else {
            for(t in 1:TIMES){
              tuning_params$mu[t, batch_no] <-
                update_tuning(batch = chains$mu[t, 1, (iter - batch_size):iter], target = 0.44,
                              batch_no = batch_no - 1, tuning_param = tuning_params$mu[t, batch_no - 1])
            }
          }
        }
        if(verbose_mcmc){
          message("All done.")
        }
      }
      ## timing ----
      if(iter %% timing_chkpt == 1){
        timing <- Sys.time() - init_time
        message(paste("iteration ", iter-1, " (", floor((iter - 1) / N_iterations * 100), "%)",
                      " [", signif(timing, 5), " ", attr(timing, "units"), "]", sep = ""))
      }
      ## save out ----
      if((iter %% save_out_rate == 1 & !is.na(save_out_file)) || iter == N_iterations + 1){
        out_partial <- list("chains" = chains, "initial" = initial, "data" = data[!(names(data) == "gradX")],
                            "N_iterations" = N_iterations,
                            "batch_size" = batch_size, "log_priors" = log_priors, "fixed" = fixed,
                            "tuning_params" = tuning_params, "total_overshoots" = total_overshoots,
                            "completed_iterations" = iter - 1,
                            "time_started" = format(init_time, "%Y%m%d_%H%M%S"),
                            "time_finished" = format(Sys.time(), "%Y%m%d_%H%M%S")
        )
        if(save_tuning_covs){
          out_partial$tuning_covs = tuning_covs
        }
        if(save_gradX){
          out_partial$data$gradX <- data$gradX
        }
        class(out_partial) <- "reDyn_mcmc"
        if(iter < N_iterations + 1){
          save(out_partial, file = save_out_file)
        }
      }
    }
  }
  ## individual samplers loop ----
  else {
    ld <- matrix(NA, 2, N_iterations + 1)
    ld[1, 1] <- get_ll_z(s = data$s, mu = chains$mu[, , 1], z = chains$z[, 1],
                         sigsq_mu = chains$sigsq_mu[1], tausq = chains$tausq[1],
                         beta = chains$beta[, 1], sigsq_s = chains$sigsq_s[1],
                         times = data$times, obstimes = data$obstimes, gradX = data$gradX)
    ld[2, 1] <- get_lfc_theta(theta = chains$theta[, 1], alpha = chains$alpha[1], z = chains$z[, 1],
                              mu = chains$mu[, , 1], g0 = chains$g0[1], gmax = chains$gmax[1],
                              times = data$times, W = data$W)
    if(min(ld[, 1]) == -Inf){
      stop("Proposed path extends beyond support of covariates (gradX, W). ",
           "Please choose another initial value for mu.")
    }
    for(iter in 2:(N_iterations + 1)){
      if(iter == turn_on_verbose){
        verbose_mcmc <- TRUE
      }
      ## alpha ----
      if("alpha" %in% fixed){
        chains$alpha[iter] <- chains$alpha[iter - 1]
      } else {
        chains$alpha[iter] <- chains$alpha[iter - 1]
        for(rep in 1:alpha_blk_reps){
          alpha_sample <-
            sample_rw(prev = chains$alpha[iter - 1], tune = tuning_params$alpha,
                      get_ld = function(prev){
                        get_lfc_theta(alpha = prev, theta = chains$theta[, iter - 1],
                                      z = chains$z[, iter - 1], mu = chains$mu[, , iter - 1],
                                      g0 = chains$g0[iter - 1], gmax = chains$gmax[iter - 1],
                                      times = data$times, W = data$W)
                      },
                      log_prior = log_priors$alpha, ld_prev = ld[2, iter - 1],
                      verbose_sampler = verbose_mcmc)
          alpha_blk[alpha_blk_reps * (iter - 2) + rep + 1] <-
            alpha_blk[alpha_blk_reps * (iter - 2) + rep] * (2 * (ld[2, iter - 1] == alpha_sample$ld) - 1)
          chains$alpha[iter] <- alpha_sample$draw
          ld[2, iter - 1] <- alpha_sample$ld
        }
      }
      ## beta ----
      if("beta" %in% fixed){
        chains$beta[, iter] <- chains$beta[, iter - 1]
      } else {
        beta_sample <-
          vec_sample_RW(prev = chains$beta[, iter - 1],
                        tune_cov = tuning_params$beta[batch_no] * tuning_covs$beta[, , batch_no],
                        get_ld = function(prev){
                          get_ll_z(beta = prev, s = data$s, mu = chains$mu[, , iter - 1],
                                   z = chains$z[, iter - 1], sigsq_mu = chains$sigsq_mu[iter - 1],
                                   tausq = chains$tausq[iter - 1], sigsq_s = chains$sigsq_s[iter - 1],
                                   times = data$times, obstimes = data$obstimes, gradX = data$gradX)
                        },
                        log_prior = log_priors$beta,
                        ld_prev = ld[1, iter - 1], verbose_sampler = verbose_mcmc)
        chains$beta[, iter] <- beta_sample$draw
        ld[1, iter - 1] <- beta_sample$ld
      }
      ## theta ----
      if("theta" %in% fixed){
        chains$theta[, iter] <- chains$theta[, iter - 1]
      } else {
        theta_sample <-
          vec_sample_RW(prev = chains$theta[, iter - 1],
                        tune_cov = tuning_params$theta[batch_no] * tuning_covs$theta[, , batch_no],
                        get_ld = function(prev){
                          get_lfc_theta(theta = prev, alpha = chains$alpha[iter],
                                        z = chains$z[, iter - 1], mu = chains$mu[, , iter - 1],
                                        g0 = chains$g0[iter - 1], gmax = chains$gmax[iter - 1],
                                        times = data$times, W = data$W)
                        },
                        log_prior = log_priors$theta, ld_prev = ld[2, iter - 1],
                        verbose_sampler = verbose_mcmc)
        chains$theta[, iter] <- theta_sample$draw
        ld[2, iter - 1] <- theta_sample$ld
      }
      ## sigsq_mu ----
      if("sigsq_mu" %in% fixed){
        chains$sigsq_mu[iter] <- chains$sigsq_mu[iter - 1]
      } else {
        sigsq_mu_sample <-
          sample_rw(prev = chains$sigsq_mu[iter - 1], tune = tuning_params$sigsq_mu,
                    get_ld = function(prev){
                      get_ll_z(sigsq_mu = prev, s = data$s, mu = chains$mu[, , iter - 1],
                               z = chains$z[, iter - 1], beta = chains$beta[, iter],
                               tausq = chains$tausq[iter - 1], sigsq_s = chains$sigsq_s[iter - 1],
                               times = data$times, obstimes = data$obstimes, gradX = data$gradX)
                    },
                    log_prior = log_priors$sigsq_mu, ld_prev = ld[1, iter - 1],
                    verbose_sampler = verbose_mcmc)
        chains$sigsq_mu[iter] <- sigsq_mu_sample$draw
        ld[1, iter - 1] <- sigsq_mu_sample$ld
      }
      ## sigsq_s ----
      if("sigsq_s" %in% fixed){
        chains$sigsq_s[iter] <- chains$sigsq_s[iter - 1]
      } else {
        ## MH version ----
        # sigsq_s_sample <-
        #   sample_rw(prev = chains$sigsq_s[iter - 1], tune = tuning_params$sigsq_s,
        #             get_ld = function(prev){
        #               get_ll_z(sigsq_s = prev, s = data$s, mu = chains$mu[, , iter - 1],
        #                        z = chains$z[, iter - 1], beta = chains$beta[, iter],
        #                        tausq = chains$tausq[iter - 1], sigsq_mu = chains$sigsq_mu[iter],
        #                        times = data$times, obstimes = data$obstimes, gradX = data$gradX)
        #             },
        #             log_prior = log_priors$sigsq_s, ld_prev = ld[1, iter - 1], verbose_sampler = verbose_mcmc)
        # chains$sigsq_s[iter] <- sigsq_s_sample$draw
        # ld[1, iter - 1] <- sigsq_s_sample$ld
        ## Gibbs version ----
        chains$sigsq_s[iter] <-
          sample_sigsq_s(mu = chains$mu[, , iter - 1], s = data$s, times = data$times,
                         obstimes = data$obstimes, prior_params = log_priors$sigsq_s)
        ld[1, iter - 1] <-
          get_ll_z(s = data$s, mu = chains$mu[, , iter - 1], z = chains$z[, iter - 1],
                   sigsq_mu = chains$sigsq_mu[iter], tausq = chains$tausq[iter - 1],
                   beta = chains$beta[, iter], sigsq_s = chains$sigsq_s[iter],
                   times = data$times, obstimes = data$obstimes, gradX = data$gradX)
      }
      ## tausq ----
      if("tausq" %in% fixed){
        chains$tausq[iter] <- chains$tausq[iter - 1]
      } else {
        tausq_sample <-
          sample_rw(prev = chains$tausq[iter - 1], tune = tuning_params$tausq,
                    get_ld = function(prev){
                      get_ll_z(tausq = prev, s = data$s, mu = chains$mu[, , iter - 1],
                               z = chains$z[, iter - 1], beta = chains$beta[, iter],
                               sigsq_s = chains$sigsq_s[iter], sigsq_mu = chains$sigsq_mu[iter],
                               times = data$times, obstimes = data$obstimes, gradX = data$gradX)
                    },
                    log_prior = log_priors$tausq, ld_prev = ld[1, iter - 1], verbose_sampler = verbose_mcmc)
        chains$tausq[iter] <- tausq_sample$draw
        ld[1, iter - 1] <- tausq_sample$ld
      }
      ## g0 ----
      if("g0" %in% fixed){
        chains$g0[iter] <- chains$g0[iter - 1]
      } else {
        g0_sample <-
          sample_rw(prev = chains$g0[iter - 1], tune = tuning_params$g0,
                    get_ld = function(prev){
                      get_lfc_theta(g0 = prev, theta = chains$theta[, iter],
                                    z = chains$z[, iter - 1], mu = chains$mu[, , iter - 1],
                                    alpha = chains$alpha[iter], gmax = chains$gmax[iter - 1],
                                    times = data$times, W = data$W)
                    },
                    log_prior = log_priors$g0, ld_prev = ld[2, iter - 1], verbose_sampler = verbose_mcmc)
        chains$g0[iter] <- g0_sample$draw
        ld[2, iter - 1] <- g0_sample$ld
      }
      ## gmax ----
      if("gmax" %in% fixed){
        chains$gmax[iter] <- chains$gmax[iter - 1]
      } else {
        gmax_sample <-
          sample_rw(prev = chains$gmax[iter - 1], tune = tuning_params$gmax,
                    get_ld = function(prev){
                      get_lfc_theta(gmax = prev, theta = chains$theta[, iter],
                                    z = chains$z[, iter - 1], mu = chains$mu[, , iter - 1],
                                    alpha = chains$alpha[iter], g0 = chains$g0[iter],
                                    times = data$times, W = data$W)
                    },
                    log_prior = log_priors$gmax, ld_prev = ld[2, iter - 1], verbose_sampler = verbose_mcmc)
        chains$gmax[iter] <- gmax_sample$draw
        ld[2, iter - 1] <- gmax_sample$ld
      }
      ## z ----
      if("z" %in% fixed){
        chains$z[, iter] <- chains$z[, iter - 1]
      } else {
        pr_zeq1 <-
          get_fc_z(mu = chains$mu[, , iter - 1], sigsq_mu = chains$sigsq_mu[iter],
                   tausq = chains$tausq[iter], beta = chains$beta[, iter],
                   theta = chains$theta[, iter], alpha = chains$alpha[iter],
                   g0 = chains$g0[iter], gmax = chains$gmax[iter],
                   times = data$times, gradX = data$gradX, W = data$W)
        chains$z[, iter] <- sapply(pr_zeq1, function(prob){
          sample(x = 1:0, size = 1, prob = c(prob, 1-prob))
        })
      }
      ## mu ----
      if("mu" %in% fixed){
        chains$mu[, , iter] <- chains$mu[, , iter - 1]
      } else {
        for(d in 1:2){
          sample_mu_d <-
            vec_sample_RW(prev = chains$mu[, d, iter - 1],
                          tune_cov = tuning_params$mu[batch_no] * tuning_covs$mu,
                          tune_cov_chol = tuning_mu_chol,
                          get_ld = function(prev){
                            mu <- cbind(prev, chains$mu[, 2, iter - 1])
                            if(d == 2) mu <- cbind(chains$mu[, 1, iter], prev)
                            get_ll_z(mu = mu, s = data$s, z = chains$z[, iter],
                                     sigsq_mu = chains$sigsq_mu[iter], tausq = chains$tausq[iter],
                                     beta = chains$beta[, iter], sigsq_s = chains$sigsq_s[iter],
                                     times = data$times, obstimes = data$obstimes, gradX = data$gradX)
                          }, log_prior = log_priors$mu, ld_prev = ld[1, iter - 1],
                          verbose_sampler = verbose_mcmc)
          chains$mu[, d, iter] <- sample_mu_d$draw
          ld[1, iter - 1] <- sample_mu_d$ld
        }
      }
      ## ----
      ## ld ----
      ld[1, iter] <- get_ll_z(s = data$s, mu = chains$mu[, , iter], z = chains$z[, iter],
                              sigsq_mu = chains$sigsq_mu[iter], tausq = chains$tausq[iter],
                              beta = chains$beta[, iter], sigsq_s = chains$sigsq_s[iter],
                              times = data$times, obstimes = data$obstimes, gradX = data$gradX)
      ld[2, iter] <- get_lfc_theta(theta = chains$theta[, iter], alpha = chains$alpha[iter], z = chains$z[, iter],
                                   mu = chains$mu[, , iter], g0 = chains$g0[iter], gmax = chains$gmax[iter],
                                   times = data$times, W = data$W)
      ## tuning ----
      if(iter %% batch_size == 1 & iter < N_iterations + 1){
        batch_no = batch_no + 1
        for(param in names(tuning_params)){
          if(param %in% c("alpha", "mu")) next
          if(param %in% fixed){
            tuning_params[[param]][batch_no] <- tuning_params[[param]][batch_no - 1]
          } else {
            if(dim(tuning_covs[[param]])[1] == 1){ ## check to see if tuning covariance exists.
              tuning_params[[param]][batch_no] <-
                update_tuning(batch = chains[[param]][(iter - batch_size):iter],
                              batch_no = batch_no - 1, tuning_param = tuning_params[[param]][batch_no - 1])
            } else {
              tuning_update_stuff <-
                vec_update_TUNING(batch = matrix(chains[[param]][, (iter - batch_size):iter], ncol = batch_size + 1),
                                  batch_no = batch_no - 1, tuning_param = tuning_params[[param]][batch_no - 1],
                                  tune_cov = tuning_covs[[param]][, , batch_no - 1])
              tuning_covs[[param]][, , batch_no] <- tuning_update_stuff$tune_cov
              tuning_params[[param]][batch_no] <- tuning_update_stuff$param
            }
          }
        }
        if(!"alpha" %in% fixed){
          tuning_params$alpha[batch_no] <-
            update_tuning(batch = alpha_blk[(alpha_blk_reps * ((iter - 1) - batch_size) + 1):(alpha_blk_reps * (iter - 1) + 1)],
                          batch_no = batch_no - 1, tuning_param = tuning_params$alpha[batch_no - 1])
        }
        if(!("mu" %in% fixed)){
          tuning_params[["mu"]][batch_no] <-
            update_tuning(batch = chains[["mu"]][1, 1, (iter - batch_size):iter], target = 0.23,
                          batch_no = batch_no - 1, tuning_param = tuning_params[["mu"]][batch_no - 1])
          tuning_covs[["mu"]][, , batch_no] <- tuning_covs[["mu"]][, , batch_no - 1]
          # tuning_update_stuff <-
          #   vec_update_TUNING(batch = matrix(chains$mu[, 1, (iter - batch_size):iter], ncol = batch_size + 1),
          #                     batch_no = batch_no - 1, tuning_param = tuning_params$mu[batch_no - 1],
          #                     tune_cov = tuning_covs$mu[, , batch_no - 1])
          # tuning_covs$mu[, , batch_no] <- tuning_update_stuff$tune_cov
          # tuning_params$mu[batch_no] <- tuning_update_stuff$param
        }
      }
      ## timing ----
      if(iter %% timing_chkpt == 1){
        timing <- Sys.time() - init_time
        message(paste("iteration ", iter-1, " (", floor((iter - 1) / N_iterations * 100), "%)",
                      " [", signif(timing, 5), " ", attr(timing, "units"), "]", sep = ""))
      }
      ## save out ----
      if((iter %% save_out_rate == 1 & !is.na(save_out_file)) || iter == N_iterations + 1){
        out_partial <- list("chains" = chains, "initial" = initial, "data" = data[!(names(data) == "gradX")],
                            "N_iterations" = N_iterations,
                            "batch_size" = batch_size, "log_priors" = log_priors, "fixed" = fixed,
                            "tuning_params" = tuning_params, "total_overshoots" = total_overshoots,
                            "completed_iterations" = iter - 1,
                            "time_started" = format(init_time, "%Y%m%d_%H%M%S"),
                            "time_finished" = format(Sys.time(), "%Y%m%d_%H%M%S")
        )
        if(save_tuning_covs){
          out_partial$tuning_covs = tuning_covs
        }
        if(save_gradX){
          out_partial$data$gradX <- data$gradX
        }
        class(out_partial) <- "reDyn_mcmc"
        if(iter < N_iterations + 1){
          save(out_partial, file = save_out_file)
        }
      }
    }
  }
  ## save final ----
  chains_used <- lapply(chains, function(param){
    if(length(dim(param)) == 2){
      array(param[, used_iterations], dim = c(dim(param)[1], length(used_iterations)))
    } else if(length(dim(param)) == 3){
      array(param[, , used_iterations], dim = c(dim(param)[1:2], length(used_iterations)))
    }
  })
  out <- out_partial
  out$chains <- chains_used
  out$used_iterations <- used_iterations
  return(out)
}
