The scripts and data files contained in this directory may be used to reproduce the results in Hooten et al. (2018) related to the movement of a mountain lion in Colorado, USA and an African buffalo in Kruger National Park, South Africa. All R scripts are intended to be run with /code/ as the working directory.

Scripts use the functions in the included 'reDyn' R package by Henry Scharf.

The 'reDyn' R package may be installed using the following command in an interactive R session:

install.packages("reDyn_0.5.2.tar.gz", repos = NULL)
